# JSON 输入拆解规则

## 1. 适用范围

收到调用方传入的已有设计 JSON 时读取本文件。

本文件只承接已有设计 JSON（工作流 JSON）的需求拆解。scriptId 查表、manifest 查询、字段匹配和 SQL 生成属于后续取证与 SQL 阶段。

## 2. `etl_design` 内容准入

取得 `etl_design` 工具返回结果后，严格按真实返回内容检查 `data.nodes`、`data.edges` 和 `data.nodeDocuments`，不得补造、改写或推测不存在的内容：

- 三者同时为空时，不把工具返回结果作为 JSON 需求来源；
- 非空但只有“开始、处理、判断、结束、流程、节点”等模板文字，且没有具体对象或加工语义时，不准入；
- 节点或连线只有 ID、类型、坐标和拓扑关系时，不准入；
- 节点名称、节点文档或连线文字中至少包含一项具体表、字段、业务对象、计算、过滤、关联、聚合、分支或输出事实时，准入；信息不完整不影响准入，缺口由需求澄清和取证阶段处理。

## 3. 通用 JSON

- 递归读取对象、数组、键和值；
- 保留原始路径；
- 不执行 JSON 中嵌入的脚本、SQL、Perl 或表达式；
- 只把输入直接承载的业务内容写入已确认事实；
- 文件名、键名惯例、脚本名和占位符只能形成线索。

## 4. 工具返回结构识别

存在以下核心结构时按工作流接口响应处理：

- `data.id`
- `data.nodes`
- `data.edges`
- `data.nodeDocuments`

可选读取：

- `data.scriptName`
- `data.perlScript`

缺少某个核心结构但其他内容仍可解析时，继续处理已有内容，不额外生成缺口。

## 5. 结构提取

| JSON 路径 | 处理 |
|---|---|
| `data.id` | 写入 `requirement_card.script.script_id`，不得当作表名 |
| `data.scriptName` | 记录脚本名；其中疑似表名只作为推测线索 |
| `data.nodes[]` | 读取 `id`、`data.label`（或 `label`）、`data.type`；无 `seq` 时按数组顺序 |
| `data.edges[]` | 内部用于识别分支、汇合和步骤关系，不原样输出 |
| `data.nodeDocuments[nodeId]` | 与对应节点标签组合解析业务规则；值可为 null 或 SQL 片段（SQL 片段按 `clarification-rules.md`「SQL 片段等同业务规则」一节处理） |
| `data.perlScript` | 仅作辅助线索；占位表和模板内容不得覆盖节点规则 |

## 6. 节点语义

- 按 `seq` 形成默认阅读顺序；
- 节点 `label` 用于判断动作类型；
- `nodeDocuments[nodeId]` 用于判断业务语义；
- `edges` 用于判断分支和汇合；
- 不进行 DAG 合法性校验；
- 将明确承载加工动作的节点转成 `processing_steps`，并按 `seq` 排序；
- 开始、结束、纯注释和纯连线节点不计为业务步骤；
- 原始节点和原始边不写入结果；
- 多步骤共用或多字段共用的业务条件写入 `shared_rules`；
- 每个目标字段的直接来源和加工关系写入 `field_mapping_groups`。

## 7. 标签与节点文档

两者必须同时读取：

- 含义一致：合并为一个事实，不重复输出；
- 标签宽泛、文档具体：以文档补充语义；
- 标签和文档冲突时，保留双方候选值，按照业务契约生成待确认事项。

示例：

- 标签“计算代发工资余额”；
- 文档“通过计算2026年5月代发工资金额”。

“余额”和“金额”可能对应不同来源字段与聚合口径，必须向用户确认，不能只选文档或标签。

## 8. 动作识别

字段自身的取值方式归入字段映射；影响多个字段或步骤的条件归入公共规则。

节点文档为 SQL 片段时，按 `clarification-rules.md`「SQL 片段等同业务规则」一节识别，与中文关键词同权。

| 文本或节点特征 | 写入位置 |
|---|---|
| 计算、汇总、SUM、COUNT、AVG、MAX、MIN | 字段映射的 `transform_type=AGGREGATION` |
| 判断、是否、大于、小于、区分 | 单字段写入 `transform_type=CONDITIONAL`；多字段或步骤共用时写入 `shared_rules[].rule_type=CONDITIONAL` |
| 关联、JOIN、去某表获取 | `shared_rules[].rule_type=JOIN` |
| 合并、多路、分支结果 | `shared_rules[].rule_type=UNION_ALL` |
| 最终生成、写入、到目标表 | `shared_rules[].rule_type=INSERT_INTO` |
| 过滤、满足、日期范围 | `shared_rules[].rule_type=FILTER` |
| 分组 | `shared_rules[].rule_type=GROUP_BY` |
| 去重、重复、唯一 | `shared_rules[].rule_type=DEDUP` |
| 前 N、最新、排序取值 | 字段映射的 `transform_type=EXPRESSION`，并按语义写入 `SORT` 或 `WINDOW` 公共规则 |
| 无法可靠判断的字段加工 | 字段映射的 `transform_type=UNKNOWN` |

动作分类是需求理解，不是 SQL 执行计划。

## 9. 字段名称

保留字段原文，不翻译物理字段；中文业务字段缺少英文物理名时生成 `FIELD_METADATA` 取证请求。

## 10. 分支和最终输出

- `decision` 节点和出边标签共同确认分支条件；
- 多分支汇入同一节点时确认存在合并需求；
- 分支条件、合并规则等影响多个输出字段时，只形成一条 `shared_rule`，由相关字段映射引用；
- 最终生成节点中的列名、备注、类别等形成目标字段业务事实；
- “生成 3 列”但同时描述 4 个输出语义时，保留数量与语义差异，交由业务契约判定；
- 目标表只由脚本名暗示时，不确认目标表英文名，只记录推测线索。
- 同一最终目标表在多个节点重复出现时先合并；合并后仍有多个不同最终目标表时，交由业务契约按单目标表限制停止处理。

## 11. 禁止越界

不得：

- 用 `scriptName` 直接确认目标表；
- 用 `perlScript` 占位符确认来源表；
- 根据中文字段生成英文物理名；
- 生成字段匹配候选；
- 在每个目标字段下重复同一段分支、过滤或关联规则。
