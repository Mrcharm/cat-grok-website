# 查询路由与受控范围

## 目录

1. [使用边界](#1-使用边界)
2. [受控查询关系](#2-受控查询关系)
3. [受控表清单](#3-受控表清单)
4. [查询目的路由](#4-查询目的路由)
5. [受控样例查询](#5-受控样例查询)

## 1. 使用边界

本 Reference 用于把取证意图映射为数据库查询工具可接受的 `query_purpose` 和语义参数。SQL 仅是受控数据库工具内部构造查询的参考，不得由 Skill 直接执行、返回或写入证据卡。

统一约束：

- 每次调用 `database_query` 都固定传入 `datasourceName: "底座数据库"`；不得覆盖、改名或使用近义词替代；
- 每次实际数据库查询只允许执行一条 `SELECT`；一个 `query_purpose` 可以按依赖顺序执行多条受控查询；
- `FROM`、`JOIN` 必须显式使用本文件声明的 `dmsp` 受控表；
- 禁止 `SELECT *`；
- 禁止访问系统目录和真实业务物理表；
- 参数必须绑定，不得把自然语言直接拼接为 SQL；
- 只使用已有参数生成查询条件，缺少的参数不参与查询；
- 候选、策略、算子和表规模查询使用明确 `LIMIT`；
- 完整字段清单使用分页，不得因默认上限截断；
- 严格表范围存在时，只能查询允许的表 ID 交集。

## 2. 受控查询关系

```text
etl_rel_script_table.tbl_id
        -> tm_db_table.GUID
             |-> tm_db_schema.GUID（通过 DATABASE_SCHEMA）
             |-> tm_db_table_col.TABLE_GUID
                       -> dc_data_item.DItm_ID（通过 DATA_ITEM_CODE）
                                  -> dc_data_domain_code.Dmn_ID

etl_strategy_framework       独立策略框架
etl_zichaxun_framework       独立加工算子框架
```

严格范围由 `target_table_ids`、`source_table_ids`、`proc_table_ids`、`tmp_table_ids` 和 `allowed_table_ids` 合并形成。表级条件使用 `GUID IN (...)`，字段级条件使用 `TABLE_GUID IN (...)`。

## 3. 受控表清单

### 3.1 `dmsp.etl_rel_script_table`

用途：通过脚本 ID 或脚本名称查询脚本涉及的表 ID 和表角色，是“脚本 → 表范围”的入口。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | varchar(32) | 关系主键 |
| `pro_lbl_stm_guid` | varchar(32) | 物理子系统 GUID |
| `script_name` | varchar(100) | 脚本名称 |
| `script_id` | varchar(32) | 脚本编号 |
| `catalog_id` | varchar(32) | catalog 编号 |
| `tbl_id` | varchar(32) | 表 ID |
| `tbl_etl_type` | varchar(20) | 表角色 |

角色解释：`dim` 为目标表，`src` 为来源表，`src_proc` 为步骤结果或中间表，`tmp` 为临时表。

- 关联：`tbl_id = dmsp.tm_db_table.GUID`
- 支持：`GET_TARGET_TABLE`
- 前置：至少有 `script_id` 或 `script_name`
- 证据位置：`evidence_card.tables[]` 中目标表和来源表的 `table_id/role`

### 3.2 `dmsp.tm_db_table`

用途：查询表 ID、中英文名、schema 引用、物理属性和表规模元数据。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `GUID` | varchar(32) | 表 ID |
| `DATA_TBL_ENG_NM` | varchar(255) | 表英文名 |
| `DATA_TBL_CHN_NM` | varchar(255) | 表中文名 |
| `DB_CLASSIFICATION` | varchar(60) | 数据库类型 |
| `DATABASE_SCHEMA` | varchar(255) | schema 元数据引用 |
| `PHYSICAL_STRATEGY` | varchar(60) | 物理化策略 |
| `SENSITIVE_LEVEL` | varchar(2) | 敏感级别 |
| `IS_VIEW` | char(1) | 是否视图 |
| `PHYSICAL_TABLE_TYPE` | varchar(100) | 物理表类型 |
| `TABLE_SIZE_MB` | decimal(20,4) | 表大小，单位 MB |
| `TABLE_ROW_CNT` | bigint | 表记录数 |
| `TABLE_MAGNITUDE_TYPE` | varchar(60) | 表数量级分类 |

- 关联：`GUID = etl_rel_script_table.tbl_id`
- 关联：`DATABASE_SCHEMA = tm_db_schema.GUID`
- 关联：`GUID = tm_db_table_col.TABLE_GUID`
- 支持：`SEARCH_TABLE_CANDIDATES`、`GET_TABLE_FIELD_ELEMENT_MANIFEST`、`GET_TABLE_SCHEMA`、`GET_TABLE_SIZE_META`
- 前置：候选查询需要表中英文名或关键词；精确查询需要表 ID
- 证据位置：目标表或来源表的名称、ID、schema 前置引用和 `table_size`

### 3.3 `dmsp.tm_db_table_col`

用途：通过唯一表 ID 查询字段中英文名、物理类型、数据项编号、口径及四类键标识。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `GUID` | varchar(64) | 字段元数据主键 |
| `TABLE_GUID` | varchar(50) | 所属表 ID |
| `COL_EN_NAME` | varchar(255) | 字段英文名 |
| `COL_CN_NAME` | varchar(255) | 字段中文名 |
| `DATA_TYPE` | varchar(255) | 字段物理类型 |
| `IS_NULL` | char(1) | 可空/非空标识，按实际元数据解释 |
| `DEFAULT_VALUE` | varchar(20) | 默认值 |
| `IS_PRIMARY` | char(1) | 主键标识 |
| `IS_PI` | char(1) | 分布键标识 |
| `IS_PARTITION_KEY` | char(1) | 分区键标识 |
| `IS_BUSINESS_DATE` | char(1) | 业务日期标识 |
| `DATA_ITEM_CODE` | varchar(255) | 数据项编号 |
| `CALIBER_DESC` | mediumtext | 字段物理口径 |

四类键标识只有字符 `1` 表示“是”；字符 `0`、空值和其他值均不进入对应键证据。

- 关联：`TABLE_GUID = tm_db_table.GUID`
- 关联：`DATA_ITEM_CODE = dc_data_item.DItm_ID`
- 支持：`GET_TABLE_FIELD_ELEMENT_MANIFEST`、`GET_TABLE_SCHEMA`、`GET_FIELD_SCHEMA`、`GET_TABLE_KEYS`、`GET_CODE_VALUES`
- 前置：必须先获得唯一表 ID
- 证据位置：表的 `fields` 和 `key_field_refs`

### 3.4 `dmsp.tm_db_schema`

用途：把表元数据中的 schema 引用转换为实际 schema 名称，或按 schema 名称反查元数据 ID。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `GUID` | varchar(32) | schema 元数据 ID |
| `SKEMA` | varchar(60) | schema 名称 |

- 关联：`GUID = tm_db_table.DATABASE_SCHEMA`
- 支持：`GET_SCHEMA_INFO`、`GET_TABLE_FIELD_ELEMENT_MANIFEST`、`GET_TABLE_SCHEMA`
- 前置：有 schema 元数据 ID 或明确 schema 名称
- 证据位置：目标表或来源表的 `schema_name`

### 3.5 `dmsp.dc_data_item`

用途：查询数据项编号、数据项中英文名称及所属数据域，是字段数据项到码值域的桥梁。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `GUID` | varchar(64) | 元数据主键 |
| `DItm_ID` | varchar(30) | 数据项编号 |
| `Chn_nm` | varchar(200) | 数据项中文名 |
| `EngShtNm` | varchar(200) | 数据项英文简称 |
| `Dmn_ID` | varchar(64) | 数据域编号 |
| `Dmn_Chn_Nm` | varchar(200) | 数据域中文名 |

- 关联：`DItm_ID = tm_db_table_col.DATA_ITEM_CODE`
- 关联：`Dmn_ID = dc_data_domain_code.Dmn_ID`
- 支持：`GET_DATA_ITEM_BY_NAME`、`GET_CODE_VALUES`
- 前置：有数据项名称、编号或已绑定字段的 `DATA_ITEM_CODE`
- 证据位置：字段的 `data_item`

### 3.6 `dmsp.dc_data_domain_code`

用途：根据已确定的数据域编号查询码值及其中文含义。关于码值的查询必须用到此表

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `GUID` | varchar(64) | 元数据主键 |
| `Dmn_ID` | varchar(128) | 数据域编号 |
| `Cd_ValSt` | varchar(64) | 代码取值 |
| `Cd_Chn_Nm` | varchar(500) | 代码中文名 |

- 关联：`Dmn_ID = dc_data_item.Dmn_ID`
- 支持：`GET_CODE_VALUES`
- 前置：唯一表 ID、唯一字段和可解析的数据项编号
- 证据位置：`evidence_card.code_values`

### 3.7 `dmsp.etl_strategy_framework`

用途：查询追加、删除/插入、全表清空/插入、拉链、更新、临时表复制等 ETL 策略框架。只返回候选框架，不替需求方决定策略。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | int(11) | 主键 |
| `strategy_name` | varchar(255) | 策略名称 |
| `sql_framework` | text | 策略框架 |

- 关联：无
- 支持：`GET_ETL_STRATEGY_FRAMEWORK`
- 前置：需求中存在明确策略名称或关键词
- 证据位置：`evidence_card.strategies`

### 3.8 `dmsp.etl_zichaxun_framework`

用途：查询子查询、去重、分组、TOP-N、窗口函数、EXISTS 等加工算子框架。只返回候选框架，不生成业务 SQL。

允许字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | int(11) | 主键 |
| `suanzi_name` | varchar(255) | 算子名称 |
| `sql_framework` | text | 算子框架 |

- 关联：无
- 支持：`GET_ETL_ZICHAXUN_FRAMEWORK`
- 前置：需求中存在明确加工算子名称或关键词
- 证据位置：`evidence_card.operators`

## 4. 查询目的路由

需求卡片中的取证类型按下表转换，不新增查询目的：

| `evidence_type` | 查询路线 |
|---|---|
| `SCRIPT_TABLE_MAPPING` | `GET_TARGET_TABLE` |
| `TABLE_METADATA` | `SEARCH_TABLE_CANDIDATES`，唯一命中后按需执行 MANIFEST |
| `FIELD_METADATA` | 无表 ID 时先定位表，再执行 `GET_FIELD_SCHEMA` 或 MANIFEST |
| `DATA_ITEM` | 已绑定字段时取字段数据项；只有数据项名称时执行 `GET_DATA_ITEM_BY_NAME` |
| `SCHEMA_INFO` | `GET_SCHEMA_INFO` 或 MANIFEST |
| `TABLE_KEYS` | `GET_TABLE_KEYS` 或 MANIFEST |
| `CODE_VALUES` | `GET_CODE_VALUES` |
| `ETL_STRATEGY` | `GET_ETL_STRATEGY_FRAMEWORK` |
| `ETL_OPERATOR` | `GET_ETL_ZICHAXUN_FRAMEWORK` |
| `TABLE_SIZE_META` | `GET_TABLE_SIZE_META` |

| `query_purpose` | 使用场景 | 必要语义参数 | 主查表 | 结果位置 |
|---|---|---|---|---|
| `GET_TARGET_TABLE` | 按脚本查询表角色 | `script_id` 或 `script_name` | `etl_rel_script_table` | 脚本、目标表、来源表 |
| `SEARCH_TABLE_CANDIDATES` | 按表中英文名或关键词定位表 | `table_en_name`、`table_cn_name` 或 `table_keyword` | `tm_db_table` | 表候选 |
| `GET_TABLE_FIELD_ELEMENT_MANIFEST` | 批量收集表、schema、字段和键 | `table_ids` | `tm_db_table`、`tm_db_schema`、`tm_db_table_col` | 表完整证据 |
| `GET_TABLE_SCHEMA` | 简单查询单表字段清单 | `table_id` | `tm_db_table`、`tm_db_schema`、`tm_db_table_col` | 表及字段 |
| `GET_FIELD_SCHEMA` | 查指定字段中英文名、类型、数据项 | `table_id/table_ids` 加字段名 | `tm_db_table_col` | 字段证据 |
| `GET_TABLE_KEYS` | 查四类键字段 | `table_id/table_ids` | `tm_db_table_col` | 表键字段 |
| `GET_SCHEMA_INFO` | 查 schema 名称 | `schema_guid/schema_guids/schema_name` | `tm_db_schema` | 表 schema |
| `GET_CODE_VALUES` | 查字段码值 | `table_id` 加唯一字段 | 字段、数据项、码值三表 | 码值 |
| `GET_DATA_ITEM_BY_NAME` | 按数据项名称查询数据项 | 数据项中英文名或关键词 | `dc_data_item` | 字段数据项 |
| `GET_ETL_STRATEGY_FRAMEWORK` | 查 ETL 策略框架 | `strategy_name` | `etl_strategy_framework` | 策略 |
| `GET_ETL_ZICHAXUN_FRAMEWORK` | 查加工算子框架 | `suanzi_name` | `etl_zichaxun_framework` | 算子 |
| `GET_TABLE_SIZE_META` | 查表大小、行数和数量级 | `table_id` | `tm_db_table` | 表规模 |

路由原则：

- 需求卡片或多项证据收集：优先 MANIFEST。
- 单独问某表完整字段：使用 `GET_TABLE_SCHEMA`。
- 单独问某字段：使用 `GET_FIELD_SCHEMA`。
- 用户在 MANIFEST 完成后新增字段：已知表 ID 时使用 `GET_FIELD_SCHEMA` 或 `GET_DATA_ITEM_BY_NAME` 定向补查，不重跑整表 MANIFEST。
- 单独问键：使用 `GET_TABLE_KEYS`，一次返回四类键。
- 策略和算子不得互相替代。
- 只有名称时不得跳过表候选直接查询字段。

## 5. 参考样例查询

### 5.1 `GET_TARGET_TABLE`

```sql
SELECT script_id, script_name, tbl_id, tbl_etl_type
FROM dmsp.etl_rel_script_table
WHERE script_id = '{script_id}';
```

### 5.2 `SEARCH_TABLE_CANDIDATES`

先精确、后模糊。精确查询无结果后才能使用关键词。

```sql
SELECT GUID, DATA_TBL_ENG_NM, DATA_TBL_CHN_NM, DATABASE_SCHEMA,
       IS_VIEW, PHYSICAL_TABLE_TYPE
FROM dmsp.tm_db_table
WHERE DATA_TBL_ENG_NM = '{table_en_name}'
   OR DATA_TBL_CHN_NM = '{table_cn_name}'
LIMIT 20;
```

### 5.3 `GET_TABLE_FIELD_ELEMENT_MANIFEST`

同一 `query_purpose` 可由数据库工具内部执行三条受控查询，Skill 仍只发起一个语义查询项。

```sql
SELECT GUID, DATA_TBL_ENG_NM, DATA_TBL_CHN_NM, DATABASE_SCHEMA,
       PHYSICAL_STRATEGY, IS_VIEW, PHYSICAL_TABLE_TYPE
FROM dmsp.tm_db_table
WHERE GUID IN ({table_ids})
LIMIT {table_count};
```

```sql
SELECT GUID, SKEMA
FROM dmsp.tm_db_schema
WHERE GUID IN ({schema_guids})
LIMIT {schema_count};
```

```sql
SELECT GUID, TABLE_GUID, COL_EN_NAME, COL_CN_NAME, DATA_TYPE,
       IS_NULL, DEFAULT_VALUE, IS_PRIMARY, IS_PI, IS_PARTITION_KEY,
       IS_BUSINESS_DATE, DATA_ITEM_CODE, CALIBER_DESC
FROM dmsp.tm_db_table_col
WHERE TABLE_GUID IN ({table_ids})
ORDER BY TABLE_GUID, COL_EN_NAME
LIMIT {page_size} OFFSET {offset};
```

### 5.4 `GET_TABLE_SCHEMA`

```sql
SELECT T.GUID, T.DATA_TBL_ENG_NM, T.DATA_TBL_CHN_NM, S.SKEMA,
       C.GUID AS COL_GUID, C.COL_EN_NAME, C.COL_CN_NAME, C.DATA_TYPE,
       C.IS_PRIMARY, C.IS_PI, C.IS_PARTITION_KEY, C.IS_BUSINESS_DATE,
       C.DATA_ITEM_CODE, C.CALIBER_DESC
FROM dmsp.tm_db_table T
LEFT JOIN dmsp.tm_db_schema S ON T.DATABASE_SCHEMA = S.GUID
JOIN dmsp.tm_db_table_col C ON T.GUID = C.TABLE_GUID
WHERE T.GUID = '{table_id}'
ORDER BY C.COL_EN_NAME
LIMIT {page_size} OFFSET {offset};
```

### 5.5 `GET_FIELD_SCHEMA`

中文名精确匹配：

```sql
SELECT GUID, TABLE_GUID, COL_EN_NAME, COL_CN_NAME, DATA_TYPE,
       IS_PRIMARY, IS_PI, IS_PARTITION_KEY, IS_BUSINESS_DATE,
       DATA_ITEM_CODE, CALIBER_DESC
FROM dmsp.tm_db_table_col
WHERE TABLE_GUID IN ({table_ids})
  AND COL_CN_NAME = '{field_cn_name}'
LIMIT 20;
```

英文名匹配使用 `LOWER(COL_EN_NAME) = LOWER('{field_en_name}')`。只有精确查询无结果时才能执行模糊查询；多候选交由用户确认。

### 5.6 `GET_TABLE_KEYS`

```sql
SELECT GUID, TABLE_GUID, COL_EN_NAME, COL_CN_NAME, DATA_TYPE,
       IS_PRIMARY, IS_PI, IS_PARTITION_KEY, IS_BUSINESS_DATE
FROM dmsp.tm_db_table_col
WHERE TABLE_GUID IN ({table_ids})
  AND (
      IS_PRIMARY = '1'
      OR IS_PI = '1'
      OR IS_PARTITION_KEY = '1'
      OR IS_BUSINESS_DATE = '1'
  )
ORDER BY TABLE_GUID, COL_EN_NAME
LIMIT {page_size} OFFSET {offset};
```

### 5.7 `GET_SCHEMA_INFO`

```sql
SELECT GUID, SKEMA
FROM dmsp.tm_db_schema
WHERE GUID IN ({schema_guids})
LIMIT {schema_count};
```

### 5.8 `GET_CODE_VALUES`

```sql
SELECT C.TABLE_GUID, C.COL_EN_NAME, C.COL_CN_NAME, C.DATA_TYPE,
       C.DATA_ITEM_CODE, I.DItm_ID, I.Chn_nm, I.EngShtNm,
       I.Dmn_ID, I.Dmn_Chn_Nm, D.Cd_ValSt, D.Cd_Chn_Nm
FROM dmsp.tm_db_table_col C
JOIN dmsp.dc_data_item I ON C.DATA_ITEM_CODE = I.DItm_ID
JOIN dmsp.dc_data_domain_code D ON I.Dmn_ID = D.Dmn_ID
WHERE C.TABLE_GUID = '{table_id}'
  AND (
      LOWER(C.COL_EN_NAME) = LOWER('{field_en_name}')
      OR C.COL_CN_NAME = '{field_cn_name}'
  )
ORDER BY D.Cd_ValSt
LIMIT 200;
```

字段没有 `DATA_ITEM_CODE` 时返回空结果，不猜测数据域。

### 5.9 `GET_DATA_ITEM_BY_NAME`

```sql
SELECT DItm_ID, Chn_nm, EngShtNm, Dmn_ID, Dmn_Chn_Nm
FROM dmsp.dc_data_item
WHERE Chn_nm = '{data_item_zh_name}'
   OR LOWER(EngShtNm) = LOWER('{data_item_en_name}')
LIMIT 20;
```

### 5.10 `GET_ETL_STRATEGY_FRAMEWORK`

```sql
SELECT id, strategy_name, sql_framework
FROM dmsp.etl_strategy_framework
WHERE strategy_name LIKE '%{strategy_name}%'
LIMIT 10;
```

### 5.11 `GET_ETL_ZICHAXUN_FRAMEWORK`

```sql
SELECT id, suanzi_name, sql_framework
FROM dmsp.etl_zichaxun_framework
WHERE suanzi_name LIKE '%{suanzi_name}%'
LIMIT 10;
```

### 5.12 `GET_TABLE_SIZE_META`

```sql
SELECT GUID, DATA_TBL_ENG_NM, DATA_TBL_CHN_NM,
       TABLE_SIZE_MB, TABLE_ROW_CNT, TABLE_MAGNITUDE_TYPE
FROM dmsp.tm_db_table
WHERE GUID = '{table_id}'
LIMIT 1;
```
