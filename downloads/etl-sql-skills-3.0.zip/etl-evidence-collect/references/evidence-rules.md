# 证据收集与合并规则

> 本文件只规定需要模型判断的语义规则；字段结构和状态约束以输出 Schema 为准。

## 1. 输入优先级

同一事实冲突时，按“用户当前修正 → 用户已确认信息 → 本轮数据库有效结果 → 上一轮 `evidence_card` → 需求卡片事实”的顺序采用。

用户补充必须是明确、可落入对应证据位置的信息。模糊意见不得覆盖已有有效证据。

## 2. 查询规划

`query_purpose` 的权威枚举、必要语义参数、主查表和选择哪个 query_purpose 的路由原则见 `references/whitelist-query-routing.md` 第 4 节「查询目的路由」，本文件不重复枚举、不重复写路由决策。不得创造别名、兼容枚举或额外查询目的。

规划时的判定规则：

- 只有唯一表候选时才能自动追加依赖表 ID 的后续查询。
- 需求卡片已产生 `CODE_VALUES`，或加工规则中的过滤条件明确使用代码、状态、标志、类型、枚举或码值域时，字段证据返回非空 `DATA_ITEM_CODE` 后自动追加 `GET_CODE_VALUES`；没有 `DATA_ITEM_CODE` 时不得猜测数据域。
- 查询项按 `query_purpose + normalized_input` 去重。
- `normalized_input` 只保留该查询目的允许的语义参数，不包含自然语言指令或 SQL。

缺口回补输入（`evidence_card` + `gaps[]`）不重建 `query_plan`：只针对 `gaps[]` 生成新增查询项并追加，已有查询项与非 FAILED 证据原样保留、不重查，仅 FAILED 项可重试。

## 3. 查询依赖

每轮按 `query_plan.items[]` 顺序选择最多 3 个依赖已满足且彼此独立、查询签名不同的 `PENDING` 查询单元。依赖项只有在其上游查询取得 `SUCCESS` 后才可执行；同批查询项不得互相依赖。

上游为 `NEED_CONFIRMATION` 时，依赖项保持 `PENDING` 等待确认；上游为 `FAILED` 或 `CONFIRMED_SKIP` 且无法取得必需参数时，依赖项转为 `FAILED` 并说明缺失的依赖。

查询结果产生新的必要条件时，只追加后续 `PENDING` 查询项，本轮不执行新项。新项沿用 `query_purpose + normalized_input` 去重，不得改写已有 `query_id`。典型链路：

- 表中文名/英文名 → 表候选 → 唯一表 ID → 按目标字段清单执行字段证据；
- 字段中文名/英文名 → 唯一表 ID → 字段证据；
- 字段 → 数据项编号 → 数据项/数据域 → 码值；
- 脚本 ID → 表角色及 ID → 按需求字段清单执行字段证据。

## 4. 查询项状态判定

查询项状态取值以 schema 的 `queryItem.status` 为准，只使用 `PENDING`/`SUCCESS`/`FAILED`/`NEED_CONFIRMATION`/`CONFIRMED_SKIP`，不记录 `RUNNING`、`EMPTY` 或其他状态。

状态判定语义：

- 唯一、有效、在允许范围内的结果 → `SUCCESS`（来源可为数据库或用户补充）；
- 查询条件明确但无记录 → `NEED_CONFIRMATION`；
- 多个候选或输入不足 → `NEED_CONFIRMATION`；
- 最终执行错误 → `FAILED`；
- 参数、枚举、范围或安全门禁错误 → `FAILED`；
- 用户已明确允许忽略 → `CONFIRMED_SKIP`。

待确认项必须记录查询对象、查询条件和需要用户补充的内容；不得扩大查询或自行选择候选。

SQL 必需目标字段查询无结果或存在多个候选时，作为例外生成 `NEED_CONFIRMATION` 查询项及 `evidence_card.pending_confirmations`，写明所属目标表、字段中文名、加工规则上下文和需要用户校对的内容；该事项解决前不得返回 `COMPLETED`。

分页型查询（MANIFEST、`GET_TABLE_SCHEMA` 等）在工具返回 `has_more=true` 时，本查询项保持 `PENDING`，不得仅因已取得部分字段就标 `SUCCESS`；只有在 `has_more=false` 且本轮结果完整后才可标 `SUCCESS`。

## 5. 失败处理

- 工具调用的重试、超时与限流由平台兜底；本技能不自行重试、不判断网络或限流状态。
- 输出只保留最终状态和当前真实错误，不输出尝试次数与逐次错误历史。
- 单个查询项失败不升级为 Skill 顶层 `ERROR`。

## 6. 用户补充

用户提供对应有效信息时：

1. 将查询项改为 `SUCCESS`；
2. 证据来源改为 `USER_SUPPLIED`；
3. 删除对应待确认事项；
4. 当前有效值以用户补充为准。

用户确认不再获取时：

1. 将查询项改为 `CONFIRMED_SKIP`；
2. 删除对应待确认事项；
3. 在查询项的 `result_summary` 保留精简跳过原因；
4. 未知物理值不输出对应字段。

用户补充或确认跳过后，删除对应的旧候选、错误和重试信息。

## 7. 用户修订需求

用户明确修改加工场景、表、字段或映射规则时，直接更新当前需求卡片、查询计划和相关证据；删除已失效内容，保留未受影响的内容，不重新调用需求澄清技能。

用户只补充物理事实或选择候选时，不修订需求卡片，直接按第 6 节更新当前检查点。

## 8. 证据主本与合并

需求卡片输入存在时：

1. 在 `requirement_card` 中完整保留未被用户修改的需求字段，尤其是 `shared_rules`、`field_mapping_groups` 及其全部 `mappings`，不改名、不压缩、不概括；
2. 在 `tables`、`code_values`、`strategies`、`operators` 中补充物理证据；
3. 只把需要用户回答的问题放入 `pending_confirmations`；失败和确认跳过只保留在 `query_plan.items[]`；
4. 不得把需求卡片重新抄写成另一套脚本、场景、步骤、规则或字段映射结构；用户明确修订时只更新对应内容，其他字段保持不变。

默认按需求卡片的目标字段与来源字段清单执行定向字段取证；`evidence_card` 只投影当前需求相关字段、未决候选、主键、分布键、分区键和业务日期字段。仅当字段清单不可枚举或用户明确要求整表结构时才使用 MANIFEST，且其结果同样只投影需求相关字段。用户新增字段时在已知表 ID 下追加 `GET_FIELD_SCHEMA` 或 `GET_DATA_ITEM_BY_NAME`，不扩大为 MANIFEST。

物理证据包括：表中英文名、表 ID 和 Schema；字段中英文名、物理类型和数据项编号；主键、分布键、分区键和业务日期字段；数据项及数据域；规则实际使用的码值；实际采用的策略和加工算子。

目标表和来源表 Schema 只能来自用户明确输入或当前有效数据库证据；缺失时继续取证，不得默认任何 Schema，也不得按名称习惯补造。

Schema 无法确认时生成 `NEED_CONFIRMATION`，已取得的其他证据继续保留。

## 9. 键字段

`tm_db_table_col` 的四个标识字段均按字符 `0/1` 解释，只有值为 `1` 时记入相应证据：

- `IS_PRIMARY` → 主键；
- `IS_PI` → 分布键；
- `IS_PARTITION_KEY` → 分区键；
- `IS_BUSINESS_DATE` → 业务日期字段。

字段物理类型使用 `DATA_TYPE`。数据项类型也指该物理类型，不得用数据域名称替代。

## 10. 证据来源

每项当前有效证据标记为 `DATABASE`（来自批准数据库工具）、`USER_SUPPLIED`（来自用户明确补充）或 `MIXED`（一个合并对象同时包含两类当前有效来源），枚举取值以 schema 的 `sourceType` 为准。

存在可用追溯标识时输出 `evidence_refs`；没有时省略，不输出空数组或编造标识。`depends_on` 仅在查询项确有依赖时输出。

工具返回的表 GUID、schema GUID 等内部标识可保留在结构化证据中用于后续调用，但不得进入面向用户的展示正文。

每个表证据至少必须有一个非空表 ID、英文名或中文名。只有 schema 而无法识别所属表时，不得创建空表对象；应先要求补充或定位对应表。
