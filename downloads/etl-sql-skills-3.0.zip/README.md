# ETL-SQL 技能包 v3.0

需求澄清 → 取证 → SQL 生成 → 文档记录 → 安全检核 全链路 Agent Skills。
