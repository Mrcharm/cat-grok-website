# ETL-SQL 技能包 v3.0

五个协同工作的 Agent Skills，覆盖「需求澄清 → 取证 → SQL 生成 → 文档记录 → 安全检核」的 ETL 开发全链路。

## 技能清单

| 技能 | 作用 |
|---|---|
| `etl-requirement-clarify` | 把自然语言 / JSON / Excel / 已有设计转译为标准 ETL 需求澄清卡片，区分已确认、待确认、待取证三类事项 |
| `etl-evidence-collect` | 把取证事项转为受控查询计划，调用批准的数据库查询工具，汇总为唯一结构化 evidence_card |
| `etl-sql-create` | 把结构化事实转换为可检核的 SQL 草案；已有草案时按反馈或检核问题定向修订。默认 PostgreSQL 方言 |
| `etl-md-write` | 将各阶段产出写入 / 更新 PLAN.md 与 RECORD.md，调用 publishArtifact 展示 |
| `etl-check-ruler` | 检核 SQL，只返回高危与超高危问题；工具不可用时按静态规则兜底。不执行、不改写 SQL |

## 链路上游依赖

```
etl-requirement-clarify  →  etl-evidence-collect  →  etl-sql-create  →  etl-check-ruler
                                     ↓                      ↓
                                          etl-md-write（记录与展示）
```

## 使用方式

将 `etl-*` 目录整体放入你的 Agent 技能目录（如 Claude Code 的 `~/.claude/skills/`），Agent 会按 `SKILL.md` 的 description 自动判断何时调用。

每个技能目录下的 `references/` 包含按需加载的规则与 Schema，由 SKILL.md 的「读取说明」指定入口必读与按需加载清单。

## 说明

- 所有 IP、密钥、Token 与本地路径已在发布前清除。
- 数据库查询固定使用受控数据源，不直接连接业务库。
- SQL 生成产出的是待独立检核的草案，自检通过不等于最终检核通过。
