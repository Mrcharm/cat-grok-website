﻿# 来源 JSON 字段映射

本文件只定义 Markdown 内容从来源 JSON 的哪个字段取得。章节样式和可读文本格式见 `markdown-templates.md`；章节定位、更新和错误处理见技能契约。

## 1. 来源识别

业务内容只取请求中的 `source_payload`。

| 来源类型 | 识别字段 |
|---|---|
| 需求澄清 | `schema_version=etl-requirement-clarify` |
| 证据收集 | `schema_version=etl-evidence-collect` |
| SQL 生成 | `schema_version=etl-sql-create` |
| SQL 检核 | `schema_version=etl-check-ruler` |

无法识别已有 Skill 结果类型时，仅在用户明确要求记录且存在 `source_payload.content` 时，将该字段写入通用内容记录；否则不建立映射。

## 2. 主计划

主计划当前阶段读取请求顶层 `current_stage`；该字段只用于定位阶段，不写入正文。

| Markdown 内容 | JSON 来源 |
|---|---|
| 阻塞错误 | 当前来源结果的 `errors[]` |
| 取证子计划 | `query_plan.items[]` |
| SQL 生成子计划 | `generation_plan.steps[]` |
| SQL 检核子计划 | `check_plan[]` |

## 3. 需求澄清

仅当 `requirement_card` 非空时读取以下字段。

| Markdown 内容 | JSON 来源 |
|---|---|
| 脚本名称 | `requirement_card.script.script_name` |
| 脚本 ID | `requirement_card.script.script_id` |
| 加工场景 | `requirement_card.processing_scene` |
| 最终目标表 | `requirement_card.target_table` |
| 目标字段 | `requirement_card.target_fields[]` |
| 来源表 | `requirement_card.source_tables[]` |
| 加工步骤 | `requirement_card.processing_steps[]` |
| 公共规则 | `requirement_card.shared_rules[]` |
| 字段映射 | `requirement_card.field_mapping_groups[].mappings[]` |
| 本轮待确认 | `requirement_card.pending_confirmations[]` |
| 待取证事项 | `requirement_card.evidence_requests[]` |
| 错误 | `errors[]` |

关联字段：

- 字段映射的目标字段：`target_field_id` → `target_fields[].field_id`；
- 公共规则：`field_mapping_groups[].shared_rule_refs[]` → `shared_rules[]`；
- 输入来源摘要：`requirement_card.input_sources[]`；
- 来源表达式、常量和例外：`expression`、`constant_value`、`exception_detail`。

## 4. 查询计划与证据

`IN_PROGRESS` 是可写入的有效阶段结果。PLAN 查询项只读取 `source_payload.query_plan.items[]`；RECORD 证据只读取 `source_payload.evidence_card`。不得从 `display_content` 或现有 Markdown 反向恢复检查点。

### 4.1 查询计划

查询事项统一读取 `source_payload.query_plan.items[]`。

| Markdown 内容 | JSON 来源 |
|---|---|
| 编号 | `query_id` |
| 标题 | `subject` |
| 状态 | `status` |
| 当前摘要 | `result_summary` |
| 失败原因 | `error.message` |
| 待确认候选 | `candidate_items[]` |

### 4.2 证据卡片

| Markdown 内容 | JSON 来源 |
|---|---|
| 卡片类型 | `evidence_card.card_type` |
| 继承的需求卡片 | `evidence_card.requirement_card` |
| 加工场景 | `evidence_card.requirement_card.processing_scene` |
| 最终目标表 | `evidence_card.requirement_card.target_table` |
| 来源表 | `evidence_card.requirement_card.source_tables[]` |
| 加工步骤 | `evidence_card.requirement_card.processing_steps[]` |
| 公共规则 | `evidence_card.requirement_card.shared_rules[]` |
| 字段映射 | `evidence_card.requirement_card.field_mapping_groups[].mappings[]` |
| 表证据 | 实际存在的 `tables[]` |
| 码值证据 | 实际存在的 `code_values[]` |
| 策略证据 | 实际存在的 `strategies[]` |
| 算子证据 | 实际存在的 `operators[]` |
| 查询失败事项 | `query_plan.items[]` 中 `status=FAILED` |
| 确认跳过事项 | `query_plan.items[]` 中 `status=CONFIRMED_SKIP` |
| 待用户确认事项 | `evidence_card.pending_confirmations[]` |
| 备注 | `evidence_card.notes[]` |

字段映射的目标字段通过 `target_field_id` 关联 `evidence_card.requirement_card.target_fields[]`；公共规则通过 `shared_rule_refs[]` 关联 `evidence_card.requirement_card.shared_rules[]`。展示时保留来源字段、表达式、常量、例外和规则引用，不重新概括业务规则。

表和字段关联：

| Markdown 内容 | JSON 来源 |
|---|---|
| 目标表 | `evidence_card.tables[]` 中 `role=TARGET` |
| 来源表 | `evidence_card.tables[]` 中 `role=SOURCE` |
| 表名和 Schema | `tables[].name`、`tables[].schema_name` |
| 字段 | `tables[].fields[]` |
| 表规模 | `tables[].table_size` |
| 键字段 | `tables[].key_field_refs` → 同表 `fields[].field_ref` |
| 字段中英文名 | `fields[].name` |
| 字段物理类型 | `fields[].data_type` |
| 数据项编号 | `fields[].data_item.item_code` |
| 键类型 | `fields[].key_roles[]` |
| 证据来源 | 表或字段的 `source_type` |

## 5. SQL 生成

| Markdown 内容 | JSON 来源 |
|---|---|
| SQL 子计划 | `generation_plan.steps[]` |
| SQL 方言 | 顶层 `dialect` |
| 生成类型 | 顶层 `generation_mode` |
| 草案标识 | `sql_draft.draft_id` |
| SQL 语句 | `sql_draft.sql_text` |
| 脚本、目标表、结论 | `generation_record.overview` |
| 准入、证据引用、阻塞项 | `generation_record.evidence_admission` |
| 全局步骤规划 | `generation_record.global_step_plan[]` |
| 表级映射框架 | `generation_record.table_frameworks[]` |
| 字段映射 | `generation_record.field_mappings[]` |
| 生成缺口 | `gaps[]` |
| 生成错误 | `errors[]` |

## 6. SQL 检核

| Markdown 内容 | JSON 来源 |
|---|---|
| 检核子计划 | `check_plan[]` |
| 检核状态 | 顶层 `status` |
| 检核依据 | `check_record.result_basis` |
| 高危和超高危问题 | 顶层 `error_items[]` |
| 风险等级 | `error_items[].risk_level` |
| 问题说明 | `error_items[].problem` |
| 问题位置 | `error_items[].location` |
| 修订要求 | `error_items[].repair_requirement` |
| 技能错误 | `errors[]` |
