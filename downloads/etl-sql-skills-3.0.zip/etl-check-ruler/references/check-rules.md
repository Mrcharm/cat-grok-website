# checkSqlUsingPOST 检核与静态兜底规则

本文件是 etl-check-ruler 的完整检核规则，分两节：主路径（调工具）和静态兜底（工具不可用时）。

## 一、调用 checkSqlUsingPOST（主路径）

### 调用

- 工具：`checkSqlUsingPOST`
- 入参：`{"sql":"<原始 SQL 文本>"}`

SQL 必须原样放入 `sql`，不得格式化、修复、转写，也不得增加其他参数。

### 成功结果处理

工具成功返回后，递归扫描结果中的对象和数组：

1. 对象存在 `ruleLevel` 且值严格等于“高危”或“超高危”时，保留完整对象；
2. 其他对象继续递归扫描其属性；
3. 数组按原顺序扫描；
4. 低危、中危、提示和普通建议不进入输出。

风险映射：

- `ruleLevel=高危` → `risk_level=HIGH`；
- `ruleLevel=超高危` → `risk_level=ULTRA_HIGH`。

将命中对象整理为 `rule_id`、`problem`、可选的 `location` 和 `repair_requirement`；字段名称不固定时生成不改变原意的可读摘要。

工具返回业务问题表示检核成功完成，不属于调用失败，不得因此转静态检核。

### 失败与降级

工具调用由平台兜底重试、超时与限流。只有当平台明确告知 `checkSqlUsingPOST` 不可用或未接入时，才转第二节静态检核，不返回逐次错误历史。

输入无效或工具参数错误属于确定性错误，不转静态检核，直接 `INPUT_INVALID`。

## 二、静态兜底规则（平台告知工具不可用时）

仅在平台明确告知 `checkSqlUsingPOST` 不可用或未接入时执行。只报告能够从当前 SQL 或已提供 `evidence_card` 确认的问题；不执行 SQL，不查询元数据，不推测表用途。

### 超高危规则

- **ULTRA_DROP_PRODUCTION_TABLE**：SQL 删除非会话临时表，且该对象属于生产表或目标/来源表。不命中：明确的会话临时表清理。修订要求：移除生产表删除语句，改为证据允许的数据处理方式。
- **ULTRA_DML_WITHOUT_WHERE**：`DELETE` 或 `UPDATE` 没有有效 `WHERE` 条件。修订要求：补充已经确认的数据边界；不能确认时交回用户或证据阶段。
- **ULTRA_UNCONFIRMED_TRUNCATE**：使用 `TRUNCATE`，但当前已确认事实未授权全表清空。修订要求：移除 `TRUNCATE`，或取得明确授权和数据边界。
- **ULTRA_OUT_OF_EVIDENCE_SCOPE**：提供了 `evidence_card`，SQL 引用了证据范围之外的生产表。跳过：独立检核未提供 `evidence_card`。修订要求：只使用已确认表，或先补充相应证据。

### 高危规则

- **HIGH_SELECT_STAR**：生产加工查询使用 `SELECT *` 或 `别名.*`。修订要求：显式列出目标字段及对应表达式。
- **HIGH_JOIN_WITHOUT_ON**：显式 `JOIN` 缺少 `ON`/`USING`，使用 `ON 1=1`，或通过逗号并列表形成隐式连接。修订要求：补充已确认的关联字段和条件。
- **HIGH_INSERT_SELECT_COUNT_MISMATCH**：能够静态确定 `INSERT` 目标字段数与 `SELECT` 输出字段数不一致。修订要求：按目标字段顺序补齐或删除 SELECT 表达式。
- **HIGH_UNCLOSED_STRUCTURE**：`CASE`、括号或事务块明显未闭合。修订要求：补齐对应的 `END`、右括号或事务结束语句。
- **HIGH_MISSING_SCHEMA**：应引用生产对象的位置缺少 Schema 或对应的 `${来源Schema}`、`${目标Schema}` 占位符；会话临时表除外。修订要求：使用已经确认的 Schema；缺失时返回取证，不得默认。
- **HIGH_HARDCODED_RUN_DATE**：业务日期或批次日期被写成固定日期常量，而需求要求跑批参数。修订要求：替换为已确认的日期参数占位符，不得自行创造参数名。
- **HIGH_HISTORY_CHAIN_INCOMPLETE**：已确认是历史拉链加工，但 SQL 缺少必要的开链或关链动作。修订要求：按已确认的生效、失效边界补齐完整链路。
- **HIGH_FULL_WRITE_WITHOUT_DELETE_BOUNDARY**：已确认是全量重写，但 SQL 没有明确的数据删除或覆盖边界。修订要求：补齐经确认的写入前数据边界，不得默认全表清理。
- **HIGH_ANALYZE_INCOMPLETE**：统计信息语句缺少目标 Schema、目标表或已确认的日期参数。修订要求：按目标数据库约定补齐完整统计信息调用。

### 输出限制

每个命中项只生成 `HIGH` 或 `ULTRA_HIGH`。无法确认、仅属风格偏好或只是普通优化建议时不输出。

## 三、结果来源

`result_basis` 只能为 `HTTP_API` 或 `STATIC_FALLBACK`：前者表示结果来自 `checkSqlUsingPOST`，后者表示来自静态兜底。`INPUT_INVALID`、`ERROR` 时不输出 `check_record`。
