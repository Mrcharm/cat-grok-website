# PostgreSQL SQL 生成规则

## 1. 方言范围

当前输入输出契约只接受 `POSTGRESQL`。MySQL、TiDB 仅保留临时表关键字差异，待方言契约开放后使用，不表示当前已支持完整脚本生成。

## 2. 标识符与 Schema

- 来源生产表使用 `${来源Schema}.TABLE_NAME`，目标生产表使用 `${目标Schema}.TABLE_NAME`。
- `${` 和 `}` 是SQL的跑批替换占位符，不是 PostgreSQL 原生参数。
- 表和字段英文名直接使用已确认物理名；不自行改变大小写或增加双引号。
- 会话级临时表不得添加 Schema。


## 3. 会话级临时表

当方言范围是`POSTGRESQL`时，临时表，统一按 `DROP + CREATE TEMP TABLE + INSERT` 三段式生成：
当方言范围是`mysql、tidb`时，临时表，统一按 `DROP + CREATE TEMPORARY TABLE + INSERT` 三段式生成：

```sql
DROP TABLE IF EXISTS TMP_TARGET_01;

CREATE TEMP TABLE TMP_TARGET_01
(
    cst_id VARCHAR(32),
    salary_amt NUMERIC(18, 2)
)
WITH (appendonly=true, compresstype=zstd, compresslevel=5)
DISTRIBUTED BY (cst_id);

INSERT INTO TMP_TARGET_01
(
    cst_id,
    salary_amt
)
SELECT
    s.cst_id,
    SUM(s.salary_amt)
FROM ${来源Schema}.salary_detail AS s
GROUP BY
    s.cst_id;
```

约束：

- 临时表名使用 `TMP_<目标表>_<两位步骤号>`；证据明确给出可用名称时优先使用。
- `DROP TABLE IF EXISTS`、`CREATE TEMP TABLE`、`INSERT INTO ... SELECT` 必须完整生成。
- `CREATE TEMP TABLE` 必须带 `WITH (appendonly=true, compresstype=zstd, compresslevel=5)`。
- 禁止为会话级临时表使用 `${TMP_SCHEMA}` 或任何生产 Schema。
- 临时表字段只保留后续步骤实际需要的字段。
- 仅允许删除当前脚本创建的临时表。

分布规则：

- 主来源表指当前步骤 `FROM` 后的第一张生产表。
- 从主来源表证据的 `key_field_refs.distribution_keys` 读取 `IS_PI=1` 字段；能够对应到临时表字段时生成 `DISTRIBUTED BY (字段列表)`。
- 主来源表没有可用于临时表的分布键时生成 `DISTRIBUTED RANDOMLY`，不得根据主键、同名字段或经验猜测分布键。


## 4. INSERT 与 SELECT

```sql
INSERT INTO ${目标Schema}.target_table
(
    cst_id,
    total_salary
)
SELECT
    t.cst_id,
    t.total_salary
FROM tmp_target_01 AS t;
```

- 禁止 `SELECT *`。
- INSERT 字段与 SELECT 表达式数量、顺序必须一致。
- INSERT 字段顺序按目标字段证据。
- 字段别名使用目标字段英文名。
- 最终目标表采用按业务日期覆盖的可重跑写入；业务日期字段必须来自目标表证据，不得默认字段名。

## 5. JOIN

- 每个 JOIN 必须有明确类型和 ON 条件。
- 禁止 `JOIN ... ON 1=1`。
- 别名在单个 SQL 块内按来源顺序使用简短、稳定名称。
- JOIN 键数据类型不兼容且转换规则未确认时停止生成。
- 不根据主键、字段同名或经验自动创造 JOIN。

## 6. WHERE、GROUP BY、HAVING 与 ORDER BY

- 行级过滤放入 WHERE。
- 聚合后过滤放入 HAVING。
- SELECT 中存在聚合时，非聚合表达式完整进入 GROUP BY；禁止数字序号。
- ORDER BY 只在业务顺序、窗口函数或确定性取值需要时生成；普通 INSERT 不为了“整齐”排序。
- 业务日期使用 `${TXNDATE}`；不得使用 `CURRENT_DATE`、`NOW()` 等系统当天时间替代业务日期。

## 7. 字段表达式

- 直取：`s.source_col AS target_col`
- 常量：只有需求明确时生成，例如 `'01' AS target_type`
- 聚合：按规则生成 `SUM`、`AVG`、`COUNT`、`MIN`、`MAX`
- 条件：生成完整 `CASE WHEN ... THEN ... ELSE ... END`
- 码值：只使用已确认码值证据
- 空值：最终落表的全部字段按目标字段物理类型默认使用 `COALESCE`
- 日期：使用 PostgreSQL 函数并保留运行参数，例如 `TO_DATE(${TXNDATE}, 'YYYYMMDD')`

默认空值保护依据 `evidence_card.tables[].fields[].data_type`，或用户直接输入整理后的 `direct_input.field_mappings[].target_data_type`：

| 目标字段类型 | 最终落表表达式 |
|---|---|
| 字符型 | `COALESCE(expr, '')` |
| 数值型 | `COALESCE(expr, 0)` |
| 日期型 | `COALESCE(expr, TO_DATE(${TXNDATE}, 'YYYYMMDD'))` |
| 时间戳 | 使用已确认的默认值；仅业务规则明确要求系统当前时间时使用 `COALESCE(expr, CURRENT_TIMESTAMP)` |

常量、系统变量、已带 `COALESCE`、`COUNT(1)` 和已确认非空字段不重复包裹。临时表中间写入不强制应用本规则。时间戳字段没有已确认默认值且可能为空时返回 `NEED_USER_INPUT`，不得自行使用当前时间。

需要默认空值保护但目标字段物理类型缺失时返回 `NEED_EVIDENCE`，不得猜测字段类型。

## 8. 注释

所有 SQL 注释统一使用 `/* ... */`，不得使用 `--` 行注释。每段 SQL 前用块注释说明该步骤的加工目的；有中文名证据时可在字段或表引用附近生成简短块注释，无中文名证据时不翻译。

## 9. 事务与统计信息

最终目标表统一按以下顺序写入：

```sql
BEGIN WORK;

DELETE FROM ${目标Schema}.目标表
WHERE 实际业务日期字段 = TO_DATE(${TXNDATE}, 'YYYYMMDD');

INSERT INTO ${目标Schema}.目标表
(
    目标字段
)
SELECT
    汇总字段
FROM TMP_TARGET_01;

COMMIT;

SELECT ${目标Schema}.ANALYZE('目标表', '${TXNDATE}', '${TXN_DATE}');
```

- `DELETE` 必须使用证据中的目标表实际业务日期字段；缺少目标表业务日期字段时返回 `NEED_EVIDENCE`，不得默认 `DATA_DT` 或其他字段。
- 日期比较表达式按目标业务日期字段物理类型生成，并保留 `${TXNDATE}`；所需字段类型缺失且无法安全比较时返回 `NEED_EVIDENCE`。
- `${目标Schema}` 使用最终目标表的已确认 Schema，`目标表`替换为最终目标表英文名。
- `COMMIT` 后必须生成统计收集语句；`${TXNDATE}`、`${TXN_DATE}` 按平台固定占位符保留，不向用户追问参数名称或传入方式。
- 技能只生成 SQL 文本，不定义提交、调度、重试或运行结果处理机制。

## 10. 生成前自检

- 每条语句以分号结束，括号和 CASE 闭合。
- 不存在示例占位词或 `xxx`。
- 不存在 `SELECT *`、无 ON 的 JOIN、数字 GROUP BY。
- DELETE 和 UPDATE 必须有已确认 WHERE。
- 最终写入顺序为 `BEGIN WORK`、按目标业务日期删除、写入、`COMMIT`、统计收集。
- 来源生产表使用 `${来源Schema}`，目标生产表使用 `${目标Schema}`；临时表没有 Schema。
- 临时表创建时包含 `DISTRIBUTED BY` 或 `DISTRIBUTED RANDOMLY`。
- SQL 中每个生产对象和业务表达式均有需求或证据引用。
