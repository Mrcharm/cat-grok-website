#!/usr/bin/env python3
"""
盘中强度评估工具
根据分时数据计算每只标的的盘中强度分（0-100），用于盘中评估报告

用法：
    python intraday_strength.py --stocks 600519,000858 --time 10:30
    
    或通过 stdin 传入 JSON 数据：
    echo '{"stocks": [...], "index": {...}}' | python intraday_strength.py

输出格式：
{
  "time": "10:30",
  "market": {"score": 65, "level": "中性", "sh_pct": 0.82, "sz_pct": 1.05},
  "stocks": [
    {
      "code": "600519",
      "name": "贵州茅台",
      "score": 78,
      "level": "较强",
      "components": {...},
      "suggestion": "持有",
      "key_levels": {"support": 1650, "resistance": 1720}
    }
  ]
}
"""

import sys
import json
import argparse
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class QuoteSnapshot:
    """标的实时数据结构"""
    code: str
    name: str
    current_price: float
    open_price: float
    prev_close: float
    high: float
    low: float
    volume: float          # 今日累计成交量（手）
    amount: float          # 今日累计成交额（万元）
    avg_volume_20d: float  # 近20日日均量（手）
    net_inflow: float      # 大单净流入（万元）
    total_amount: float    # 总成交额（万元，用于计算净流入比例）
    
    # 分时均线
    ma5min: Optional[float] = None   # 5分钟均线当前值
    ma10min: Optional[float] = None  # 10分钟均线当前值
    ma30min: Optional[float] = None  # 30分钟均线当前值
    
    # 筹码数据（可选）
    profit_ratio: Optional[float] = None  # 获利筹码比例（0-1）
    
    # 持仓信息（可选）
    cost_price: Optional[float] = None    # 持仓成本价
    position_type: str = "tracking"       # "holding" 持仓 / "tracking" 跟踪


@dataclass
class MarketSnapshot:
    """大盘指数数据"""
    sh_pct: float   # 上证指数涨跌幅
    sz_pct: float   # 深证成指涨跌幅
    net_inflow: float  # 大盘资金净流入（亿元）


def evaluate_market_relative(stock: QuoteSnapshot, index: MarketSnapshot) -> dict:
    """
    相对大盘强度评估（30分）
    """
    # 计算标的涨跌幅
    stock_pct = (stock.current_price - stock.prev_close) / stock.prev_close * 100
    
    # 计算大盘均值（沪深平均）
    market_pct = (index.sh_pct + index.sz_pct) / 2
    
    # 相对强度
    relative = stock_pct - market_pct
    
    if relative > 3:
        pts = 30
    elif relative > 2:
        pts = 27
    elif relative > 1:
        pts = 23
    elif relative > 0:
        pts = 18
    elif relative > -1:
        pts = 12
    elif relative > -2:
        pts = 7
    else:
        pts = 3
    
    return {
        "score": pts,
        "max": 30,
        "detail": f"标的 {stock_pct:+.2f}% vs 大盘 {market_pct:+.2f}%，相对 {relative:+.2f}%"
    }


def evaluate_volume_condition(stock: QuoteSnapshot) -> dict:
    """
    量能状态评估（20分）
    """
    if stock.avg_volume_20d <= 0:
        return {"score": 10, "max": 20, "detail": "量能数据不足"}
    
    vol_ratio = stock.volume / stock.avg_volume_20d
    
    if vol_ratio >= 2.0:
        pts = 20
        tag = "极度放量"
    elif vol_ratio >= 1.5:
        pts = 17
        tag = "明显放量"
    elif vol_ratio >= 1.0:
        pts = 13
        tag = "温和放量"
    elif vol_ratio >= 0.8:
        pts = 9
        tag = "平量"
    elif vol_ratio >= 0.5:
        pts = 5
        tag = "缩量"
    else:
        pts = 2
        tag = "极度缩量"
    
    return {
        "score": pts,
        "max": 20,
        "detail": f"{tag}（当日量/均量={vol_ratio:.1f}x）"
    }


def evaluate_minute_ma(stock: QuoteSnapshot) -> dict:
    """
    分时均线多空状态评估（20分）
    """
    price = stock.current_price
    above_count = 0
    available_mas = []
    
    if stock.ma5min:
        available_mas.append(("5分钟", stock.ma5min))
        if price > stock.ma5min:
            above_count += 1
    
    if stock.ma10min:
        available_mas.append(("10分钟", stock.ma10min))
        if price > stock.ma10min:
            above_count += 1
    
    if stock.ma30min:
        available_mas.append(("30分钟", stock.ma30min))
        if price > stock.ma30min:
            above_count += 1
    
    if not available_mas:
        # 无分时均线数据，用价格与开盘/昨收的关系替代
        if price > stock.open_price > stock.prev_close:
            pts, detail = 16, "价格高于开盘价，日内趋势向上"
        elif price > stock.prev_close:
            pts, detail = 12, "价格高于昨收，小幅盈利"
        elif price > stock.open_price:
            pts, detail = 8, "价格高于开盘，但低于昨收"
        else:
            pts, detail = 4, "价格低于开盘，日内走弱"
        return {"score": pts, "max": 20, "detail": detail}
    
    total_mas = len(available_mas)
    above_ratio = above_count / total_mas
    
    if above_ratio >= 1.0:
        pts = 20
        detail = f"价格在全部 {total_mas} 条均线上方"
    elif above_ratio >= 0.67:
        pts = 15
        detail = f"价格在 {above_count}/{total_mas} 条均线上方"
    elif above_ratio >= 0.33:
        pts = 10
        detail = f"价格仅在 {above_count}/{total_mas} 条均线上方"
    else:
        pts = 4
        detail = f"价格在全部均线下方"
    
    return {"score": pts, "max": 20, "detail": detail}


def evaluate_capital_flow(stock: QuoteSnapshot) -> dict:
    """
    资金净流入评估（20分）
    """
    if stock.total_amount <= 0:
        return {"score": 10, "max": 20, "detail": "资金流数据不足"}
    
    inflow_pct = stock.net_inflow / stock.total_amount * 100  # 百分比
    
    if inflow_pct > 20:
        pts = 20
        tag = "大量资金净流入"
    elif inflow_pct > 10:
        pts = 17
        tag = "明显净流入"
    elif inflow_pct > 5:
        pts = 14
        tag = "温和净流入"
    elif inflow_pct > -5:
        pts = 8
        tag = "资金中性"
    elif inflow_pct > -10:
        pts = 5
        tag = "温和净流出"
    else:
        pts = 2
        tag = "大量净流出"
    
    return {
        "score": pts,
        "max": 20,
        "detail": f"{tag}（净流入占比 {inflow_pct:+.1f}%）"
    }


def evaluate_chip_cost(stock: QuoteSnapshot) -> dict:
    """
    筹码成本位置评估（10分）
    用获利筹码比例近似
    """
    if stock.profit_ratio is None:
        # 没有筹码数据，用价格相对昨收估算
        if stock.current_price > stock.prev_close * 1.02:
            return {"score": 8, "max": 10, "detail": "高于昨收 2%，筹码普遍获利"}
        elif stock.current_price > stock.prev_close:
            return {"score": 6, "max": 10, "detail": "小幅高于昨收，筹码基本盈亏平衡"}
        else:
            return {"score": 3, "max": 10, "detail": "低于昨收，筹码有浮亏"}
    
    chip_ratio = stock.profit_ratio  # 0-1
    
    if chip_ratio > 0.8:
        pts = 10
        detail = f"获利筹码 {chip_ratio*100:.0f}%，筹码结构良好"
    elif chip_ratio > 0.6:
        pts = 8
        detail = f"获利筹码 {chip_ratio*100:.0f}%，多数筹码盈利"
    elif chip_ratio > 0.4:
        pts = 5
        detail = f"获利筹码 {chip_ratio*100:.0f}%，筹码分布均衡"
    else:
        pts = 2
        detail = f"获利筹码仅 {chip_ratio*100:.0f}%，套牢筹码较多"
    
    return {"score": pts, "max": 10, "detail": detail}


def classify_strength(total_score: int) -> tuple:
    """根据总分返回等级和颜色标记"""
    if total_score >= 80:
        return "🔥 极强", "极强"
    elif total_score >= 60:
        return "💪 较强", "较强"
    elif total_score >= 40:
        return "😐 中性", "中性"
    elif total_score >= 20:
        return "⚠️ 偏弱", "偏弱"
    else:
        return "🔻 极弱", "极弱"


def suggest_action(score: int, stock: QuoteSnapshot, index: MarketSnapshot) -> str:
    """根据评分和持仓类型给出操作建议"""
    
    # 计算标的涨跌幅
    stock_pct = (stock.current_price - stock.prev_close) / stock.prev_close * 100
    
    if stock.position_type == "holding":
        if stock.cost_price:
            pnl_pct = (stock.current_price - stock.cost_price) / stock.cost_price * 100
        else:
            pnl_pct = 0
        
        if score >= 75:
            return "持有不动，强势可适当加仓"
        elif score >= 60:
            return "持有观望"
        elif score >= 45:
            if pnl_pct < -3:
                return "⚠️ 已亏损且强度偏弱，考虑止损"
            return "持有，注意盘面变化"
        elif score >= 30:
            return "⚠️ 强度偏弱，考虑减半仓位"
        else:
            return "🔴 止损或清仓，强度极弱"
    
    else:  # tracking
        if score >= 75:
            return "强度极佳，可考虑进场"
        elif score >= 60:
            return "强度良好，关注回调买点"
        elif score >= 45:
            return "强度一般，继续观察"
        else:
            return "强度偏弱，暂时回避"


def compute_stock_strength(stock: QuoteSnapshot, index: MarketSnapshot) -> dict:
    """
    计算单只标的的盘中强度得分
    返回完整评估结果
    """
    dimensions = {
        "vs_market": evaluate_market_relative(stock, index),
        "volume": evaluate_volume_condition(stock),
        "ma_trend": evaluate_minute_ma(stock),
        "fund_flow": evaluate_capital_flow(stock),
        "chip_position": evaluate_chip_cost(stock),
    }
    
    total = sum(c["score"] for c in dimensions.values())
    emoji_level, level = classify_strength(total)
    suggestion = suggest_action(total, stock, index)
    
    # 计算涨跌幅
    pct = (stock.current_price - stock.prev_close) / stock.prev_close * 100
    
    result = {
        "code": stock.code,
        "name": stock.name,
        "current_price": stock.current_price,
        "pct": round(pct, 2),
        "score": total,
        "level": emoji_level,
        "components": dimensions,
        "suggestion": suggestion,
        "position_type": stock.position_type,
    }
    
    if stock.cost_price:
        result["cost_price"] = stock.cost_price
        result["pnl_pct"] = round((stock.current_price - stock.cost_price) / stock.cost_price * 100, 2)
    
    return result


def render_broadcast_text(time_str: str, market: MarketSnapshot, results: list) -> str:
    """
    格式化盘中评估播报文本
    """
    # 判断大盘强弱
    avg_pct = (market.sh_pct + market.sz_pct) / 2
    if avg_pct > 1:
        market_label = "强势"
    elif avg_pct > 0:
        market_label = "偏强"
    elif avg_pct > -1:
        market_label = "偏弱"
    else:
        market_label = "弱势"
    
    lines = [
        f"⏰ **{time_str} 盘中播报**",
        "",
        f"📊 **大盘状态**：{market_label} | 沪指 {market.sh_pct:+.2f}% | 深成 {market.sz_pct:+.2f}%",
        "",
    ]
    
    # 分持仓和跟踪
    holdings = [r for r in results if r['position_type'] == 'holding']
    tracking = [r for r in results if r['position_type'] == 'tracking']
    
    if holdings:
        lines.append("🔴 **持仓标的**")
        for r in sorted(holdings, key=lambda x: -x['score']):
            cost_str = ""
            if 'pnl_pct' in r:
                cost_str = f" | 持仓盈亏 {r['pnl_pct']:+.2f}%"
            lines.append(
                f"  • **{r['code']} {r['name']}**：强度 {r['score']}/100 {r['level']} | "
                f"现价 {r['current_price']:.2f}（{r['pct']:+.2f}%）{cost_str} → **{r['suggestion']}**"
            )
        lines.append("")
    
    if tracking:
        lines.append("🟡 **跟踪标的**")
        for r in sorted(tracking, key=lambda x: -x['score']):
            lines.append(
                f"  • **{r['code']} {r['name']}**：强度 {r['score']}/100 {r['level']} | "
                f"现价 {r['current_price']:.2f}（{r['pct']:+.2f}%） → **{r['suggestion']}**"
            )
        lines.append("")
    
    # 核心判断
    if results:
        avg_score = sum(r['score'] for r in results) / len(results)
        if avg_score >= 65 and avg_pct > 0:
            key_judgment = "整体强势，持仓方向正确，可适量加仓"
        elif avg_score >= 50:
            key_judgment = "持仓标的强度尚可，维持现有仓位"
        elif avg_score >= 35:
            key_judgment = "部分标的走弱，注意风险，可适度减仓"
        else:
            key_judgment = "标的普遍偏弱，建议降低仓位，保留现金"
        
        lines.append(f"💡 **当前节点**：{key_judgment}")
    
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description="A股盘中强度评估工具")
    parser.add_argument('--json', '-j', help='输入 JSON 数据文件路径')
    parser.add_argument('--time', '-t', default='盘中', help='当前播报时间点（如 10:30）')
    parser.add_argument('--broadcast', '-b', action='store_true', help='输出格式化播报文本')
    
    args = parser.parse_args()
    
    # 读取输入数据
    if args.json:
        with open(args.json, 'r', encoding='utf-8') as f:
            data = json.load(f)
    else:
        data = json.loads(sys.stdin.read())
    
    # 解析大盘数据
    idx = data.get('index', {})
    market = MarketSnapshot(
        sh_pct=idx.get('sh_pct', 0),
        sz_pct=idx.get('sz_pct', 0),
        net_inflow=idx.get('net_inflow', 0),
    )
    
    # 解析标的数据并评分
    results = []
    for s in data.get('stocks', []):
        stock = QuoteSnapshot(
            code=s.get('code', ''),
            name=s.get('name', ''),
            current_price=s.get('current_price', 0),
            open_price=s.get('open_price', 0),
            prev_close=s.get('prev_close', s.get('current_price', 0)),
            high=s.get('high', 0),
            low=s.get('low', 0),
            volume=s.get('volume', 0),
            amount=s.get('amount', 0),
            avg_volume_20d=s.get('avg_volume_20d', 0),
            net_inflow=s.get('net_inflow', 0),
            total_amount=s.get('total_amount', s.get('amount', 1)),
            ma5min=s.get('ma5min'),
            ma10min=s.get('ma10min'),
            ma30min=s.get('ma30min'),
            profit_ratio=s.get('profit_ratio'),
            cost_price=s.get('cost_price'),
            position_type=s.get('position_type', 'tracking'),
        )
        results.append(compute_stock_strength(stock, market))
    
    if args.broadcast:
        print(render_broadcast_text(args.time, market, results))
    else:
        output = {
            "time": args.time,
            "market": {
                "sh_pct": market.sh_pct,
                "sz_pct": market.sz_pct,
                "net_inflow": market.net_inflow,
            },
            "stocks": results,
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
