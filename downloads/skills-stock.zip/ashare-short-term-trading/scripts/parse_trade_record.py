#!/usr/bin/env python3
"""
交割单标准化工具
将各类格式的交割单（Excel/CSV/文本粘贴）转为统一 JSON 结构

用法：
    python parse_trade_record.py --input <file_path> [--output <output_json>]
    
输出 JSON 格式：
[
  {
    "code": "600519",          # 股票代码（不含市场后缀）
    "name": "贵州茅台",        # 股票名称
    "direction": "buy/sell",   # 买入/卖出
    "datetime": "2026-06-25 09:31:00",  # 交易时间
    "price": 1680.00,          # 成交价
    "volume": 100,             # 成交股数
    "amount": 168000.00,       # 成交金额（元）
    "fee": 25.20,              # 手续费（元）
    "net_amount": 168025.20,   # 实际付出/收入（元）
    "account": "主账户"        # 账户标识（可选）
  }
]
"""

import sys
import json
import argparse
import re
from pathlib import Path
from datetime import datetime


def identify_format(content: str) -> str:
    """检测交割单格式类型"""
    content_lower = content.lower()
    
    # 判断各大券商格式
    if "买卖方向" in content and "成交数量" in content:
        return "standard_csv"
    elif "成交时间" in content and "证券代码" in content:
        return "broker_excel"
    elif "委托方向" in content:
        return "entrust_format"
    elif re.search(r'\d{6}\s+\w+\s+[买卖]', content):
        return "plain_text"
    else:
        return "unknown"


def normalize_direction(raw: str) -> str:
    """标准化方向字段"""
    raw = str(raw).strip()
    buy_keywords = ["买", "buy", "买入", "证券买入", "B"]
    sell_keywords = ["卖", "sell", "卖出", "证券卖出", "S"]
    
    for kw in buy_keywords:
        if kw in raw:
            return "buy"
    for kw in sell_keywords:
        if kw in raw:
            return "sell"
    return "unknown"


def normalize_datetime(raw: str) -> str:
    """标准化时间字段"""
    raw = str(raw).strip()
    formats = [
        "%Y%m%d %H%M%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y/%m/%d %H:%M:%S",
        "%Y%m%d%H%M%S",
        "%H:%M:%S",  # 仅时间（需结合日期）
        "%H%M%S",
    ]
    
    for fmt in formats:
        try:
            dt = datetime.strptime(raw, fmt)
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
    
    return raw  # 无法解析时原样返回


def normalize_code(raw: str) -> str:
    """标准化股票代码（去除市场后缀，仅保留6位数字）"""
    raw = str(raw).strip()
    # 提取6位数字
    match = re.search(r'\d{6}', raw)
    if match:
        return match.group()
    return raw


def safe_float(raw) -> float:
    """安全转换浮点数"""
    if raw is None or str(raw).strip() in ['', '-', 'nan', 'NaN']:
        return 0.0
    try:
        # 去除逗号分隔符
        return float(str(raw).replace(',', '').strip())
    except (ValueError, TypeError):
        return 0.0


def read_table_content(content: str, date_hint: str = None) -> list:
    """解析 CSV/表格格式交割单"""
    trades = []
    lines = [l.strip() for l in content.split('\n') if l.strip()]
    
    if not lines:
        return trades
    
    # 检测分隔符
    delimiter = '\t' if '\t' in lines[0] else ','
    
    # 解析标题行
    headers = [h.strip() for h in lines[0].split(delimiter)]
    
    # 字段映射
    field_map = {
        'code': ['证券代码', '股票代码', '代码', 'code'],
        'name': ['证券名称', '股票名称', '名称', 'name'],
        'direction': ['买卖方向', '委托方向', '交易方向', '方向', '买卖标志'],
        'datetime': ['成交时间', '交易时间', '委托时间', '时间'],
        'date': ['成交日期', '交易日期', '日期'],
        'time': ['成交时间', '时间'],
        'price': ['成交价格', '成交均价', '价格', '委托价格'],
        'volume': ['成交数量', '成交股数', '数量', '委托数量'],
        'amount': ['成交金额', '成交额', '金额'],
        'fee': ['手续费', '费用', '佣金'],
    }
    
    col_indices = {}
    for field, candidates in field_map.items():
        for candidate in candidates:
            if candidate in headers:
                col_indices[field] = headers.index(candidate)
                break
    
    # 解析数据行
    for line in lines[1:]:
        cells = [c.strip() for c in line.split(delimiter)]
        if len(cells) < 3:
            continue
        
        def get(field):
            idx = col_indices.get(field)
            if idx is not None and idx < len(cells):
                return cells[idx]
            return ''
        
        code = normalize_code(get('code'))
        if not re.match(r'^\d{6}$', code):
            continue  # 跳过非股票行
        
        # 处理日期+时间分开的情况
        dt_raw = get('datetime')
        if not dt_raw:
            date_raw = get('date') or date_hint or ''
            time_raw = get('time') or ''
            dt_raw = f"{date_raw} {time_raw}".strip()
        
        trade = {
            "code": code,
            "name": get('name'),
            "direction": normalize_direction(get('direction')),
            "datetime": normalize_datetime(dt_raw),
            "price": safe_float(get('price')),
            "volume": int(safe_float(get('volume'))),
            "amount": safe_float(get('amount')),
            "fee": safe_float(get('fee')),
            "net_amount": 0.0,
        }
        
        # 计算实际金额
        if trade['amount'] == 0 and trade['price'] > 0:
            trade['amount'] = trade['price'] * trade['volume']
        
        if trade['direction'] == 'buy':
            trade['net_amount'] = trade['amount'] + trade['fee']
        else:
            trade['net_amount'] = trade['amount'] - trade['fee']
        
        trades.append(trade)
    
    return trades


def read_free_text(content: str, date_hint: str = None) -> list:
    """解析纯文本格式（粘贴的交易记录）"""
    trades = []
    
    # 常见文本格式模式
    pattern = re.compile(
        r'(\d{1,2}[:/]\d{2}[:/]\d{2})\s+'  # 时间
        r'([买卖]入?出?)\s+'               # 方向
        r'(\d{6})\s+'                       # 代码
        r'([\w\u4e00-\u9fa5]+)\s+'         # 名称
        r'([\d.]+)\s+'                      # 价格
        r'(\d+)'                            # 数量
    )
    
    for match in pattern.finditer(content):
        time_str, direction, code, name, price, volume = match.groups()
        date_prefix = date_hint or datetime.now().strftime("%Y-%m-%d")
        
        trade = {
            "code": code,
            "name": name,
            "direction": normalize_direction(direction),
            "datetime": normalize_datetime(f"{date_prefix} {time_str}"),
            "price": safe_float(price),
            "volume": int(safe_float(volume)),
            "amount": safe_float(price) * int(safe_float(volume)),
            "fee": 0.0,
            "net_amount": 0.0,
        }
        trade['net_amount'] = trade['amount']
        trades.append(trade)
    
    return trades


def pair_buy_sell(trades: list) -> list:
    """
    将买入和卖出配对，生成完整的交易记录（含盈亏计算）
    同一只标的，按时间顺序先买后卖配对
    """
    from collections import defaultdict
    
    result = []
    # 按股票代码分组
    by_code = defaultdict(list)
    for t in sorted(trades, key=lambda x: x['datetime']):
        by_code[t['code']].append(t)
    
    for code, txs in by_code.items():
        buy_queue = []
        
        for tx in txs:
            if tx['direction'] == 'buy':
                buy_queue.append(tx)
            elif tx['direction'] == 'sell' and buy_queue:
                # 找匹配的买入记录（先进先出）
                buy_tx = buy_queue.pop(0)
                
                pnl = (tx['price'] - buy_tx['price']) * min(tx['volume'], buy_tx['volume'])
                pnl_pct = (tx['price'] - buy_tx['price']) / buy_tx['price'] * 100
                
                result.append({
                    **tx,
                    "buy_datetime": buy_tx['datetime'],
                    "buy_price": buy_tx['price'],
                    "sell_datetime": tx['datetime'],
                    "sell_price": tx['price'],
                    "hold_minutes": compute_hold_minutes(buy_tx['datetime'], tx['datetime']),
                    "pnl": round(pnl, 2),
                    "pnl_pct": round(pnl_pct, 2),
                })
            else:
                # 没有对应买入的卖出，或只有买入没有卖出
                result.append(tx)
        
        # 未平仓的买入记录
        for buy_tx in buy_queue:
            result.append({**buy_tx, "status": "open"})
    
    return result


def compute_hold_minutes(buy_dt: str, sell_dt: str) -> int:
    """计算持仓时长（分钟）"""
    try:
        fmt = "%Y-%m-%d %H:%M:%S"
        buy = datetime.strptime(buy_dt, fmt)
        sell = datetime.strptime(sell_dt, fmt)
        delta = sell - buy
        return max(0, int(delta.total_seconds() / 60))
    except Exception:
        return 0


def load_file(file_path: str) -> list:
    """主入口：解析交割单文件"""
    path = Path(file_path)
    
    if not path.exists():
        print(f"❌ 文件不存在: {file_path}", file=sys.stderr)
        return []
    
    suffix = path.suffix.lower()
    
    if suffix in ['.xlsx', '.xls']:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(file_path)
            ws = wb.active
            rows = list(ws.iter_rows(values_only=True))
            content = '\n'.join(['\t'.join([str(c) if c is not None else '' for c in row]) for row in rows])
            return read_table_content(content)
        except ImportError:
            print("⚠️ openpyxl 未安装，尝试读取为文本", file=sys.stderr)
    
    elif suffix == '.csv':
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            content = f.read()
        return read_table_content(content)
    
    else:
        # 尝试读取为文本
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        
        fmt = identify_format(content)
        if fmt in ['standard_csv', 'broker_excel', 'entrust_format']:
            return read_table_content(content)
        else:
            return read_free_text(content)


def main():
    parser = argparse.ArgumentParser(description="A股交割单解析工具")
    parser.add_argument('--input', '-i', help='交割单文件路径（xlsx/csv/txt）')
    parser.add_argument('--text', '-t', help='直接传入交易记录文本（用于粘贴内容）')
    parser.add_argument('--output', '-o', help='输出 JSON 文件路径（默认输出到 stdout）')
    parser.add_argument('--date', '-d', help='交易日期（格式 YYYY-MM-DD，用于补全仅有时间的记录）')
    parser.add_argument('--pair', action='store_true', help='是否进行买卖配对并计算盈亏')
    
    args = parser.parse_args()
    
    trades = []
    
    if args.input:
        trades = load_file(args.input)
    elif args.text:
        fmt = identify_format(args.text)
        if fmt in ['standard_csv', 'broker_excel']:
            trades = read_table_content(args.text, args.date)
        else:
            trades = read_free_text(args.text, args.date)
    else:
        # 从 stdin 读取
        content = sys.stdin.read()
        fmt = identify_format(content)
        if fmt in ['standard_csv', 'broker_excel']:
            trades = read_table_content(content, args.date)
        else:
            trades = read_free_text(content, args.date)
    
    if args.pair:
        trades = pair_buy_sell(trades)
    
    output_json = json.dumps(trades, ensure_ascii=False, indent=2)
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output_json)
        print(f"✅ 已解析 {len(trades)} 条交易记录，输出至 {args.output}")
    else:
        print(output_json)
    
    return trades


if __name__ == '__main__':
    main()
