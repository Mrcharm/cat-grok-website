---
name: a-share-daily-review
description: A 股收盘后全维度复盘能力，覆盖技术面、情绪面、短线博弈与板块拆解四条路径，
  外加轻量热点数据速览。自动采集指数行情、板块排行、涨停梯队、资金流向、题材 驱动与宏观指标，生成自包含 HTML 报告（ECharts
  图表）。触发词：A股复盘、 每日复盘、大盘回顾、涨停复盘、市场情绪、短线复盘、热点复盘、主力资金流向。
agent_created: true
version: 1.0.1
display_name: A股每日复盘
display_name_en: A-Share Daily Review
description_zh: A股每日收盘后全维度复盘报告生成，支持五种分析风格，输出自包含HTML报告。
description_en: Comprehensive A-share daily market review with 5 analysis
  styles, output as self-contained HTML report.
visibility: public
disable: true  # retired 2026-09-01 -> a-share-fupan
---



> [retired 2026-09-01] 本技能已由 `a-share-fupan` 替代，处于 30 天观察期（disable 状态）。恢复请删除本标注与 disable 字段。
> [retired 2026-09-01] 本技能已由 `a-share-fupan` 替代，处于 30 天观察期（disable 状态）。恢复请删除本标注与 disable 字段。
# A 股每日收盘全维复盘

## 能力概览

本 skill 提供 A 股收盘后的完整复盘能力，覆盖四条深度分析路径与一条轻量热点速览路径。
数据统一经 4 个可信 skill 获取，不依赖外部 API 或 WebSearch。

正式交付物为**自包含 HTML**（含 ECharts 图表），由 Agent 直接写入文件，**不要**跑报告生成脚本。
用户明确要求 Markdown 或微信文案时再切换格式。

> **输出约定**：交付后聊天中只给摘要 + 文件路径；含图表的报告须 `node --check` 通过后再交付。
> 遵守 wb-finance 硬约束；复盘章节结构见 `references/html_report_style.md`（可按分析路径微调配色）；
> 热点速览为橙红脉冲风格，见 `references/hotspot_report_template.html`。
>
> **加载顺序**：金融场景先加载 `wb-finance-skill` 读红线与时区口径，再调 westock / neodata 取数。

## 交易日检查

开始任何数据采集前，先判断目标日期是否为 A 股交易日。周末或中国法定节假日（A 股休市）时，告知用户「今日休市，无交易数据」，停止后续流程。

## 依赖声明

### 可信 Skill

| skill | 用途 |
|-------|------|
| **westock-data** | 结构化金融数据：指数行情、个股行情、板块排行、市场总览、涨跌分布、龙虎榜、宏观指标、新闻公告、资金流向、K线、技术指标 |
| **neodata-financial-search** | 自然语言金融数据搜索：热点个股/题材归因、驱动因素、业绩公告、涨价新闻、产业链专题、资讯研报 |
| **westock-tool** | 选股/筛股/排行：连板天梯、涨跌停排行、资金流入排行、封单量排行、成交额排行、涨跌幅排行 |
| **wb-finance-skill** | 金融分析方法论：市场状态判断（market-state.md）、题材周期分析（theme-lifecycle.md）、涨停龙头博弈（leader-game.md）、每日投研简报框架（daily-briefing.md） |

### 系统工具

- **Node.js** — westock-data / westock-tool 命令依赖；HTML 交付前 `node --check` 内联 JS 语法自检
- **Python ≥ 3.7** — 运行 `neodata-financial-search` 的 `scripts/query.py`

> 报告 HTML **由 Agent 直接写入文件**，不依赖本地数据采集或报告生成脚本。样式与结构见 `references/html_report_style.md`、`references/hotspot_report_template.html`。

---

## 数据采集流程（所有分析路径共用）

以下为基础数据采集步骤，按需取用。

### 指数行情与市场广度

```bash
# 核心指数批量行情（上证/深证/创业板/科创50/上证50/沪深300/中证1000/中证500/中证红利/北证50）
westock-data quote sh000001,sz399001,sz399006,sh000688,sh000016,sh000300,sh000852,sh000905,sh000922,bj899050 --raw

# 市场总览（含成交额、风格轮动、估值画像）
westock-data market-overview --type trade,rotation,valuation --raw

# 涨跌分布（涨停/跌停计数首选来源）
westock-data changedist --raw

# 两融余额多周期变动
westock-data market-overview --type margin
```

### 板块排行

```bash
# 行业涨幅 + 概念涨幅 + 资金流入 + 北向热门板块
westock-data sector ranking --raw

# 板块热度排名（搜索/讨论度）
westock-data hot board
```

### 涨停板与连板梯队

```bash
# 连板天梯
westock-tool ranking limitup_days --limit 50

# 涨停封单量排行
westock-tool ranking limitup_seal_volume --limit 30

# 跌停排行（连续跌停天数 + 封单量）
westock-tool ranking limitdn_days --limit 20
westock-tool ranking limitdn_seal_amount --limit 20
```

### 龙虎榜与资金流向

```bash
# 机构榜 + 游资榜
westock-data lhb --type institution,hotmoney --raw

# 近期龙虎榜股票池
westock-tool event longhu_statis_past_15

# 北向资金（个股维度）
westock-data fund flow <代码>
```

### 热点题材与驱动因素

使用 `neodata-financial-search`（`scripts/query.py` 位于该 skill 目录下；首次若 `TOKEN_EXPIRED` / `TOKEN_MISSING`，按其 SKILL.md「获取凭证」处理）：

```bash
# 热点个股及题材归因
python3 scripts/query.py --query "A股 {日期} 今日涨停股票和热门个股有哪些，为什么上涨，有什么题材概念"

# 当日市场重大事件和驱动因素
python3 scripts/query.py --query "今日A股市场重大事件和驱动因素"

# 市场聚合新闻（沪深）
westock-data news market --market hs --limit 20
```

### 宏观指标

```bash
# 核心宏观指标（GDP/CPI/PMI/工业/消费/投资）
westock-data macro indicator core_indicators_cur

# 汇率、原油、黄金（neodata-financial-search）
python3 scripts/query.py --query "今日美元兑人民币汇率"
python3 scripts/query.py --query "今日黄金和原油价格"
```

### 个股行情

```bash
# 批量实时行情
westock-data quote <代码列表>

# K 线（用于形态/趋势判断）
westock-data kline <代码> --period day --limit 60

# 技术指标
westock-data technical <代码> --group macd,rsi
```

### 注意事项

- 涨停/跌停计数始终优先使用 `changedist` 数据（`market-overview --type updown` 仅覆盖主板 10% 涨跌停限制，可能低估数量）
- 若可信 skill 返回数据为空，如实标注「当前数据源未覆盖」，不要编造数据
- 关键数据至少 2 个独立来源交叉验证
- 所有行情/板块/涨跌停/资金数据必须从上述 4 个可信 skill 获取，禁止使用 web_search/curl/第三方 API 替代

---

## 分析路径

根据用户意图选择以下五条路径之一。未指定时默认走路径一。

### 路径一：技术面三维分析

**匹配场景**：用户关注大盘技术面、指数走势、均线/指标信号，或要求 HTML 图表报告。

**分析维度**：上证指数判风险、国证2000 判进攻、全 A 数据判情绪。

**额外数据需求**（在基础采集上追加）：
- 上证指数日K线（复盘日 + 前两周，含开盘/最高/最低/收盘/成交额）
- 上证指数周K线（最近 8-12 周，判断 144 周均线、MACD 黄白线）
- 国证2000 日K线（复盘日 + 前两周）
- 技术指标：MA5/MA20/MA60/MA250、MACD、KDJ、布林带

**分析清单**：

| 阶段 | 内容 | 产出 |
|------|------|------|
| 风险面 | 上证指数：阴线结构、MACD 状态、均线站位、周/月趋势方向（顶分型/底分型判断） | 一句话定性：「可积极」还是「宜谨慎」 |
| 进攻面 | 国证2000：走好 → 可进攻；走弱 → 收缩防守。与上证对比相对强弱 | 方向判断 |
| 情绪面 | 全 A：涨跌家数 → 温度；涨停/跌停家数 → 极端情绪；成交额 → 参与度 | 情绪定位 |
| 主线面 | 领涨板块是否形成共振、是否具备延续性 | 主线判断 |
| 买点推演 | 分三档判断入场依据 | 建仓参考 |

**三档建仓参考**：

| 档位 | 类型 | 依据 |
|------|------|------|
| 第 1 档 | 左侧试探 | 支撑位 + 底分型 + 缩量止跌 |
| 第 2 档 | 趋势跟进 | 均线收复 + MACD 拐头 |
| 第 3 档 | 突破加仓 | 前高突破 + 放量确认 |

**后续关注**：3-6 个关键观察维度，每项说明信号含义。

**输出格式**：自包含 HTML，遵循 `references/html_report_style.md`（ECharts CDN、浅底深字研报风、上涨红下跌绿、首屏结论卡先行）。保存建议：`./daily-review/技术面复盘_YYYYMMDD.html`。

**写作基调**：基于数据推演，结论有依据。关键句式：「当前阶段的判断是……」「等信号确认而非提前押注」「宁可错过机会也不做无把握的决策」

**交付前必须**：`node --check` 对内联 JS 做语法自检。

### 路径二：情绪周期分析

**匹配场景**：用户关注市场情绪、短线氛围、赚钱效应与亏钱效应。

**分析维度**：五维情绪评估。

**分析清单**：

| 维度 | 核心问题 | 结论输出 |
|------|---------|---------|
| 量温度 | 涨停数、跌停数、连板数、炸板率、红盘占比 | 温度决定仓位上限 |
| 识主线 | 领涨板块与龙头、跟风是否批量跟随 | 龙头+跟风齐涨 = 情绪健康；龙头独涨 = 不健康 |
| 测亏钱效应 | 昨日追高者今日盈亏、高位股是否补跌、炸板股次日开盘表现 | 亏钱效应扩散时机会减少、陷阱增多 |
| 判持筹心态 | 持仓者卖出意愿、抛压轻重、场外资金入场意愿 | 核心是判断市场心理，不是看价格 |
| 空仓检验 | 假设空仓，选哪只标的、胜算多少、预期涨幅 vs 下跌空间 | 赢面不足 60% 则不操作 |

**输出格式**：自包含 HTML，包含大盘概览、赚钱效应、亏钱效应、情绪周期（情绪温度计 + 周期定位）、板块轮动、连板梯队（含龙头质量评级 S/A/B/C）、龙虎榜博弈、风险评估、明日策略九个板块。样式遵循 `references/html_report_style.md`。保存建议：`./daily-review/情绪周期_YYYYMMDD.html`。

**写作基调**：短句为主、结论先行。每个板块先给结论再列数据支撑。

### 路径三：短线博弈复盘

**匹配场景**：用户关注短线博弈、龙头战法、题材周期。

**分析维度**：六步博弈分析。

**分析清单**（先读取 wb-finance-skill 对应 reference 获取方法论和阈值）：

| 步骤 | 内容 | 参考方法 |
|------|------|---------|
| 定周期 | 判断情绪周期阶段（低位震荡→主升→高位震荡→主跌），依据涨停家数趋势、连板高度变化、昨日涨停今日溢价、炸板率走势 | market-state.md、theme-lifecycle.md |
| 辨两端 | 识别绝对高位（龙头）和绝对低位（首板/一进二），过滤全部中位股（三进四/四进五） | leader-game.md |
| 断时机 | 判断新题材是市场无标的可炒才走出来的，还是真正有生命力。题材出现的时机比内容重要 | theme-lifecycle.md |
| 看换手 | 评估龙头和连板票是换手上来的还是缩量一字上来的。缩量板接多了是定时炸弹 | — |
| 验人气 | 人气最高的标的是谁，人气带来的流动性溢价是短线赚钱的唯一来源 | — |
| 空仓检验 | 假设空仓，今天哪只票是舒服的买点？没找到就空仓 | — |

**输出格式**：自包含 HTML，10 个板块：大盘概览 → 周期定位（核心板块）→ 龙头梯队：绝对高位 → 低位试错：绝对低位 → 亏钱效应扫描 → 板块轮动与题材时机 → 连板梯队 → 龙虎榜博弈 → 风险评估与仓位纪律 → 明日策略。样式遵循 `references/html_report_style.md`。保存建议：`./daily-review/短线博弈_YYYYMMDD.html`。

**写作基调**：框架定义用断言语气、操作建议用概率语气、每讲一个概念必附案例。中位股一律标注为高风险区。

### 路径四：八大板块全景复盘

**匹配场景**：用户需要系统化全貌复盘，含偏差分析、下一日推演、宏观快照。

**分析维度**：八板块依次展开。

**分析清单**（严格按此顺序）：

| 序号 | 板块 | 内容 |
|------|------|------|
| 1 | 六大指数收盘 | 上证指数、中证500、科创50、创业板指、中证红利、中证1000 的收盘点位、涨跌幅、成交额、滚动 PE |
| 2 | 市场特征 | 量能（成交额变化）、风格（价值 vs 成长、大盘 vs 小盘）、赚钱效应（涨跌家数、涨跌停数） |
| 3 | 标的动态 | 用户提供的标的列表，逐个覆盖收盘价/涨跌幅、当日消息/事件、走势逻辑分析和短期预判，可按层级输出：**核心龙头**（主线辨识度最高）、**容量中军**（大资金主战场）、**20cm 弹性**（创业板/科创板高弹性标的）、**低位补涨**（补涨逻辑标的）、**风险回避**（高位分歧/可能退潮） |
| 4 | 核心驱动 | 选取 1-2 个当日最关键驱动事件，按四层分析（事实→解读→映射→操作）深度展开 |
| 5 | 领涨/领跌 | TOP 10 领涨板块（含涨跌幅和领涨股）、TOP 10 领跌板块 |
| 6 | 偏差复核 | 对比上一日推演与今日实际走势，逐指数评估方向正确性和涨跌幅区间命中率，记录偏差原因 |
| 7 | 下一日推演 | 对每个指数给出方向（看涨/看跌/震荡）、预计涨跌幅区间、推演逻辑。须考虑节假日、宏观数据发布时间、财报季等事件影响 |
| 8 | 宏观快照 | 人民币汇率、10 年期国债收益率、北向资金净流入/流出、Shibor、原油/黄金价格及其对 A 股的传导逻辑 |

**输出格式**：自包含 HTML（默认；勿再默认写 Markdown）。章节顺序即上述八板块；样式遵循 `references/html_report_style.md`。保存建议：`./daily-review/全景复盘_YYYYMMDD.html`。

**写作基调**：每个 section 控制在 150-300 字，言简意赅。每个数据区块都要有解读性判断。

---

## 板块轮动评估（优先级分级）

以下分级体系可在任意分析路径中追加，辅助次日方向排序：

| 级别 | 含义 | 操作建议 |
|------|------|----------|
| P0 | 次日最核心、最值得盯的主线方向 | 重点参与 |
| P1 | 有较强催化和承接，可能成为补充主线 | 关注确认信号 |
| P2 | 逻辑存在但资金还没完全聚焦 | 只做观察 |
| P3 | 高位分歧、退潮或只适合反抽观察 | 谨慎回避 |

---

## 市场状态快速定位

可从以下四类快速定性当日市场状态：

- **进攻**：主线明确、情绪高涨、资金聚焦，可积极操作
- **修复**：前期分歧后回暖，需确认修复强度
- **分歧**：多空博弈激烈，方向不明，需等待确认
- **退潮**：主线松动、亏钱效应扩散，应以防守为主

---

## 次日开盘关注清单

次日盘中核心关注要点（在报告末尾输出）：
- 哪些方向必须强于旧主线
- 哪些容量票不能破位
- 哪些高位票不能炸板
- 哪些信号代表退潮

---

## 热点速览路径（路径五）

当用户只需要快速数据型复盘（无需深度分析）时使用。基于 westock-data 结构化行情数据与 westock-tool 排行选股能力，自动生成包含 6 大核心模块的 HTML 可视化报告（ECharts）。

### 数据采集

```bash
# 大盘指数
westock-data quote sh000001,sz399001,sz399006,sz399005,sz399376

# 板块数据
westock-data sector ranking
westock-data hot board

# 成交额 TOP20
westock-tool ranking qt_daily --orderby Amount --limit 20 --raw

# 主力净流入 TOP20
westock-tool ranking cap_main_net --limit 20 --raw

# 10日涨幅 TOP20（排除创业板300xxx、科创板688xxx、北交所bj）
westock-tool ranking qt_chg_interval --orderby ChgPct10D --limit 50 --raw
```

> 10日涨幅排除规则：先取足够多结果（如50条），再在返回数据中过滤掉 `code` 以 `sz300`、`sh688`、`bj` 开头的条目，取剩余前20条。

### 报告生成（Agent 直接写 HTML）

采集完数据后，**直接按** `references/hotspot_report_template.html` **写出自包含 HTML**，填入真实数据与 ECharts 数组；交付前 `node --check`。

保存建议：`./daily-review/热点速览_YYYYMMDD.html`。交付前对内联 JS 执行 `node --check`。

### 报告结构

1. **报告标题**：日期 + "A股市场热点复盘报告"
2. **大盘概览**：三大指数卡片（收盘价、涨跌幅、成交额）
3. **5日板块涨幅**：横向柱状图 + 表格（前15板块）
4. **今日热点板块**：热点板块卡片（涨幅、成交额、资金流向）
5. **成交额 TOP20**：表格 + 柱状图
6. **主力净流入 TOP20**：表格 + 柱状图
7. **10日涨幅 TOP20（主板）**：表格 + 柱状图

### 单位换算

| 数据类型 | 原始单位 | 展示单位 |
|---------|---------|---------|
| 成交额/市值 | 元 | 亿元（÷100000000）|
| 主力资金 | 元 | 亿元（÷100000000）|
| 成交量 | 手 | 万手（÷10000）|

---

## 可选追加模块（所有路径可用）

以下模块可在任意分析路径基础上按需追加。

### 涨停深度拆解

当用户关注涨停复盘或连板分析时执行。采集涨停全景数据（总数/封板率/炸板数）、连板天梯、重点龙头详情，按「驱动事件 → 行业逻辑 → 个股受益 → 资金确认 → 板块联动」五步拆解精选龙头。

### 晚间/涨价/专题监控

当用户提及「热点区」「晚间公告」「涨价函」等关键词时执行。覆盖三大模块：

- **模块 A：晚间业绩公告** — H1 预增/扭亏公告，只保留盘后发布的，提取公司名/代码/核心数据/同比增幅/主营业务映射
- **模块 B：涨价函新闻汇总** — PCB/CCL、铜箔、半导体硅片、电子特气、MLCC、玻纤等产业链涨价新闻，附带可信度评级（1-5 星）
- **模块 C：临时专题** — 用户指定的产业链梳理，按环节分组输出受益方和核心公司

详见 `references/hotspot-prompts.md`。

---

## 报告交付方式（重要）

1. **默认 HTML**：五条路径正式交付物均为自包含 `.html` 文件
2. **Agent 直接写**：读取对应模板/规范后，用文件写入工具生成完整 HTML；数据采集直接调用上述可信 skill 命令，不要写本地抓数脚本
3. **模板对照**：
   - 路径一～四、涨停深度等 → `references/html_report_style.md` + `wb-finance-skill/references/html-report-style.md`
   - 路径五热点速览 → `references/hotspot_report_template.html`
   - 涨停章节内容结构可参考 `references/report-template.md`，但输出仍写成 HTML
4. **聊天**：一句摘要 + 文件路径；含图表时 `node --check` 通过后再交付

---

## 通用规范

### 颜色惯例

- 上涨：红色（`#e63946`）
- 下跌：绿色（`#2d6a4f`）
- 中国 A 股惯例，不要搞反

### 数据红线

- 不编造数据、不混淆概念、不给出具体买卖建议
- 不使用「建议买入/卖出」措辞，改用「条件→操作→止损」框架
- 数据源不可绕过：禁止使用 web_search/web_fetch/curl 替代可信 skill
- 报告中绝不暴露具体数据源名称、群名称、消息数量、文件来源或抓取路径

### 隐私与数据源口径

- 统一使用中性表述：「综合消息面」「产业催化」「市场反馈」「资金验证」「盘面表现」等
- 不出现可识别来源的描述（如具体平台名、群名、帖子数量等）
- 若某类数据未获取到，可在内部降权，但不在报告里展开来源细节

### 风险提示

报告结尾须注明：「以上分析基于公开数据，不构成投资建议」。每条策略建议后附带一句明确的风险警示。

---

## 参考文件索引

| 用途 | 路径 |
|------|------|
| HTML 输出规范（路径一～四、ECharts） | `references/html_report_style.md` |
| 热点速览 HTML 模板（路径五） | `references/hotspot_report_template.html` |
| 涨停章节内容结构参考（输出仍写 HTML） | `references/report-template.md` |
| 热点区提示词 | `references/hotspot-prompts.md` |
| 数据源参考（可信 skill 命令一览） | `references/data-sources.md` |
| 数据查询参考 | `references/api_reference.md` |
