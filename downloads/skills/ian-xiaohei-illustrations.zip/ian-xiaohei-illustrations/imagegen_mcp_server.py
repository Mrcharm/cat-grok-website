"""
通用生图 MCP Server（纯 stdio JSON-RPC，零额外依赖，仅 httpx）。
让 /ian-xiaohei-illustrations 真正出图。

环境变量：
  IMAGE_GEN_BASE_URL   生图接口完整 URL（OpenAI 兼容 images/generations 风格）
  IMAGE_GEN_API_KEY    API Key
  IMAGE_GEN_MODEL      模型名（如 doubao-seedream-4-5-251128）
  IMAGE_GEN_SIZE       尺寸（默认 1920x1920，满足 Seedream 最小像素要求）
  IMAGE_GEN_OUT_DIR    图片保存目录

工具：
  generate_image(prompt, size, n) -> 本地路径列表（逗号分隔）
"""
import os, sys, json, base64, uuid, httpx

BASE_URL = os.environ.get("IMAGE_GEN_BASE_URL", "").rstrip("/")
API_KEY = os.environ.get("IMAGE_GEN_API_KEY", "")
MODEL = os.environ.get("IMAGE_GEN_MODEL", "doubao-seedream-4-5-251128")
SIZE = os.environ.get("IMAGE_GEN_SIZE", "1920x1920")
OUT_DIR = os.environ.get("IMAGE_GEN_OUT_DIR", r"D:\workbuddy_output\写作\assets\图谱平台-illustrations")

def generate(prompt: str, size: str = "", n: int = 1) -> str:
    if not BASE_URL or not API_KEY:
        return "ERROR: 未配置 IMAGE_GEN_BASE_URL / IMAGE_GEN_API_KEY"
    os.makedirs(OUT_DIR, exist_ok=True)
    body = {"prompt": prompt, "n": n, "size": size or SIZE, "response_format": "url"}
    if MODEL:
        body["model"] = MODEL
    try:
        r = httpx.post(BASE_URL, json=body,
                       headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
                       timeout=120)
        if r.status_code != 200:
            return f"ERROR: 生图接口 {r.status_code}: {r.text[:300]}"
        data = r.json()
        paths = []
        for item in data.get("data", []):
            fn = os.path.join(OUT_DIR, f"{uuid.uuid4().hex[:8]}.png")
            if "b64_json" in item:
                open(fn, "wb").write(base64.b64decode(item["b64_json"]))
            elif "url" in item:
                open(fn, "wb").write(httpx.get(item["url"], timeout=60).content)
            else:
                continue
            paths.append(fn)
        return ("OK:" + ",".join(paths)) if paths else "ERROR: 接口未返回图片数据"
    except Exception as e:
        return f"ERROR: {str(e)[:300]}"

# ---- 最小 MCP stdio 实现 ----
TOOLS = [{
    "name": "generate_image",
    "description": "生成一张图，返回本地文件路径（逗号分隔）。prompt 为中文生图描述。",
    "inputSchema": {
        "type": "object",
        "properties": {
            "prompt": {"type": "string", "description": "生图描述"},
            "size": {"type": "string", "default": "1024x1024"},
            "n": {"type": "integer", "default": 1}
        },
        "required": ["prompt"]
    }
}]

def handle(req):
    method = req.get("method")
    pid = req.get("id")
    if method == "initialize":
        return {"jsonrpc": "2.0", "id": pid, "result": {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "imagegen-mcp", "version": "1.0"}}}
    if method == "notifications/initialized":
        return None
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": pid, "result": {"tools": TOOLS}}
    if method == "tools/call":
        name = req["params"]["name"]
        args = req["params"].get("arguments", {})
        if name == "generate_image":
            res = generate(args.get("prompt", ""), args.get("size", "1024x1024"), args.get("n", 1))
            ok = res.startswith("OK:")
            return {"jsonrpc": "2.0", "id": pid, "result": {
                "content": [{"type": "text", "text": res}],
                "isError": (not ok)}}
        return {"jsonrpc": "2.0", "id": pid, "result": {"content": [{"type": "text", "text": "unknown tool"}], "isError": True}}
    return {"jsonrpc": "2.0", "id": pid, "error": {"code": -32601, "message": "method not found"}}

def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except Exception:
            continue
        resp = handle(req)
        if resp:
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
            sys.stdout.flush()

if __name__ == "__main__":
    main()
