# 豆包 Seedream 生图配置明细

## 端点与调用

```
POST https://ark.cn-beijing.volces.com/api/v3/images/generations
Authorization: Bearer <ark-key>
Content-Type: application/json

{
  "model": "doubao-seedream-4-5-251128",
  "prompt": "...",
  "size": "1920x1920",
  "response_format": "url",
  "stream": false
}
```

## 关键约束（实测结论）

1. **size 必须 ≥ 3686400 像素**（即 1920×1920 或 2048×2048）。1024×1024、1280×720、512×512 都会被拒（`image size must be at least 3686400 pixels`）。
2. `response_format: url` 返回 TOS 临时链接（带签名，有时效），需下载保存本地；不要直接用 URL 当图。
3. model 名 `doubao-seedream-4-5-251128` 是固定字符串，不是变量。
4. ark Key 格式 `<你的豆包 API Key>`（UUID 形态），在火山方舟控制台创建。

## 本地验证命令（不耗额度时可用 /v1/models 查可用模型）

```
GET https://ark.cn-beijing.volces.com/api/v3/models
Authorization: Bearer <ark-key>
```
返回 `data[].id` 列表，确认模型确实存在再调。

## MCP server 最小实现要点

- 纯 stdio JSON-RPC，只依赖 httpx，不用 fastmcp（mcp 2.x 无 fastmcp 子模块，import 失败会让 MCP 进程 -32000 崩）。
- tools/list 返回一个 `generate_image(prompt, size, n)` 工具。
- 入参 size 缺省读环境变量 `IMAGE_GEN_SIZE`。
- 出参返回本地路径（逗号分隔）或 `ERROR: ...` 文本。
- 现成文件：`~/.workbuddy/skills/ian-xiaohei-illustrations/imagegen_mcp_server.py`
