# PPT / 申报材料真实截图脱敏清单

## 为什么必须脱敏

把获奖申报 PPT、客户交付材料当文章素材时，里面大量关系图含：
- 真实企业名称（如"某源（厦门）石化有限公司"）
- 个人姓名 / 客户编号
- 交易金额、账户信息、机构代码

这些**不能原样贴进公开文章**。即使用"某某某"部分打码，残留的编号体系和机构痕迹仍可能暴露。

## 可用 vs 不可用

| 类型 | 能否原样用 | 示例 |
|------|-----------|------|
| 平台能力架构图（只有 API/引擎/组件名） | ✅ 可用 | 规则引擎 / 图查询引擎 / Graph DBs / ES 架构图 |
| 布局模式示意图（只展示布局形态） | ✅ 可用（最好抽象重绘） | 流向/辐射/树状布局 |
| 含客户名/金额的关系图 | ❌ 不可用 | 反洗钱资金链路真实截图 |
| 含个人姓名/编号的画像图 | ❌ 不可用 | 风险画像含"某某某"+编号 |

## 处理策略

1. **可用原图**：纯架构/能力图直接提取嵌入（提取法见下）。
2. **不可用原图**：
   - 在源头 PPT 里先打码再给我；或
   - 用 ian 小黑概念图 / 手绘 SVG 抽象示意替代（只表达结构，不画真实数据）。
3. **绝不**为了"真实感"原样贴含敏感数据的截图。

## 提取 PPT 图片（python-pptx）

```python
from pptx import Presentation
import os
p = Presentation("xxx.pptx")
out = "assets/ppt真实截图"
os.makedirs(out, exist_ok=True)
for i, sl in enumerate(p.slides):
    for sh in sl.shapes:
        if sh.shape_type == 13:  # 图片
            fn = f"{out}/slide{i+1}_{sh.shape_id}.{sh.image.ext}"
            open(fn, "wb").write(sh.image.blob)
```

提取后**逐张肉眼检查**是否含敏感信息，再决定用不用。
