# -*- coding: utf-8 -*-
"""
extract_pptx_spec.py — 从任意 .pptx 实物中逆向提取「编排规范」

用途：当用户丢来一份"这版能看"的 PPT，要学习其编排框架/风格/文字结构时，
先跑这个脚本拿到硬参数，再人工判断哪些可复用、哪些是妥协。

输出（Markdown）：
  1. 画布与字体
  2. 母版固定件 —— 自动识别「多页同位置同尺寸」的 shape
  3. 配色统计（按出现次数排序，带用途推断）
  4. 字号层级分布
  5. 表格样式
  6. 逐页结构概要（供分析叙事骨架与标题句式）

用法：
  python extract_pptx_spec.py <file.pptx> [-o out.md] [--full]

  --full  额外输出每个 shape 的全部文本 run（默认只输出前 300 字/页）

依赖：python-pptx
"""
import sys, io, os, re, glob, zipfile, argparse, collections

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from pptx import Presentation

EMU_CM = 360000.0

# 常见深蓝/橙色系 → 用途推断（可自行扩展）
ROLE_HINT = [
    ('0D315C', '主色·大标题/表头底'),
    ('153B6B', '次主色·小标题/深色块'),
    ('ED792B', '强调色·章节标签/关键数字'),
    ('B4551F', '强调深·描边'),
    ('2F72C8', '亮蓝·图标/箭头/编号'),
    ('38536F', '正文'),
    ('5C6878', '次要说明'),
    ('C9DAEE', '深底上的次要文字'),
    ('D9E2EC', '描边线/表格线'),
    ('EAF2FA', '浅底·表格首列'),
    ('DCE9F7', '浅底2'),
    ('F5F8FC', '区块浅底'),
    ('FBF0E6', '强调色浅底'),
    ('F0D9C8', '强调色浅描边'),
    ('7A8899', '页码/极小注'),
    ('FFFFFF', '白·深底上文字'),
]


def cm(v):
    return None if v is None else round(v / EMU_CM, 2)


def walk_colors(node, out):
    if node.tag.split('}')[-1] == 'srgbClr':
        out.append((node.get('val') or '').upper())
    for c in node:
        walk_colors(c, out)


def shape_rect(sh):
    return (cm(sh.left), cm(sh.top), cm(sh.width), cm(sh.height))


def collect_runs(sh, limit=None):
    """返回 [(text, font_name, color_hex, bold, size_pt)]"""
    out = []
    if not sh.has_text_frame:
        return out
    for para in sh.text_frame.paragraphs:
        for r in para.runs:
            if not (r.text or '').strip():
                continue
            f = r.font
            col = None
            try:
                if f.color is not None and f.color.type is not None:
                    if 'THEME' in str(f.color.type):
                        col = 'theme:' + str(f.color.theme_color)
                    else:
                        col = str(f.color.rgb)
            except Exception:
                pass
            out.append((r.text, f.name, col, f.bold, f.size.pt if f.size else None))
            if limit and len(out) >= limit:
                return out
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pptx')
    ap.add_argument('-o', '--out', default=None)
    ap.add_argument('--full', action='store_true')
    args = ap.parse_args()

    p = Presentation(args.pptx)
    W, H = cm(p.slide_width), cm(p.slide_height)
    n = len(p.slides)
    L = []
    A = L.append

    A('# PPTX 逆向提取报告\n')
    A('来源文件：`%s`\n' % os.path.basename(args.pptx))

    # ---------- 1. 画布 ----------
    A('## 1. 画布\n')
    ratio = round(W / H, 4) if H else 0
    A('- 尺寸：**%.2f × %.2f cm**  （%d × %d EMU）' % (W, H, p.slide_width, p.slide_height))
    A('- 比例：%s' % ('16:9' if abs(ratio - 16 / 9) < 0.02 else
                    ('4:3' if abs(ratio - 4 / 3) < 0.02 else str(ratio))))
    A('- 页数：%d，版式数：%d\n' % (n, len(p.slide_layouts)))

    # ---------- 2. 字体 ----------
    fonts = collections.Counter()
    for s in p.slides:
        for sh in s.shapes:
            for t, fn, c, b, sz in collect_runs(sh):
                if fn:
                    fonts[fn] += 1
    A('## 2. 字体\n')
    if fonts:
        A('| 字体 | 使用 run 数 |')
        A('|---|---|')
        for k, v in fonts.most_common(10):
            A('| %s | %d |' % (k, v))
    A('')

    # ---------- 3. 母版固定件识别 ----------
    # 收集每页的 (name, rect)，按 rect 聚类
    page_shapes = []
    for s in p.slides:
        items = []
        for sh in s.shapes:
            r = shape_rect(sh)
            if None in r:
                continue
            items.append((sh.name, r, sh.shape_type))
        page_shapes.append(items)

    groups = collections.defaultdict(list)
    for idx, items in enumerate(page_shapes):
        for name, r, st in items:
            groups[r].append((idx, name, st))

    thr = max(2, int(n * 0.5))
    fixed = [(r, v) for r, v in groups.items() if len({i for i, _, _ in v}) >= thr]
    fixed.sort(key=lambda kv: (-len({i for i, _, _ in kv[1]}), kv[0][1], kv[0][0]))

    A('## 3. 母版固定件（自动识别：出现在 ≥%d/%d 页的同位置同尺寸元素）\n' % (thr, n))
    if fixed:
        A('| left | top | w | h | 出现页数 | 典型 name | 推测角色 |')
        A('|---|---|---|---|---|---|---|')
        for r, v in fixed:
            pages = sorted({i for i, _, _ in v})
            names = collections.Counter(nm for _, nm, _ in v).most_common(1)[0][0]
            left, top, w, h = r
            # 粗略角色推断
            if top is not None and top < 3.0 and w > 15:
                role = '页面标题'
            elif top is not None and top < 3.0 and w < 8:
                role = '右上章节标签'
            elif top is not None and top > 17.0 and left < 6:
                role = '页脚左 Logo'
            elif top is not None and top > 17.0 and left > 25:
                role = '页脚右 Logo'
            elif top is not None and top > 17.5:
                role = '页码'
            elif h is not None and h < 0.6:
                role = '分隔线/横条'
            else:
                role = ''
            A('| %s | %s | %s | %s | %d | %s | %s |' % (left, top, w, h, len(pages), names, role))
            A('<!-- pages: %s -->' % (','.join(str(i + 1) for i in pages)))
    else:
        A('_未识别到稳定固定件（可能是设计稿，或各页元素差异过大）_')
    A('')

    # 内容安全区推断
    if fixed:
        body = [r for r, v in fixed if r[1] is not None and 3.0 <= r[1] <= 17.0]
        if body:
            l = min(r[0] for r in body)
            A('- 内容安全区（由正文类固定件推断）：left ≥ %.2f' % l)
        foot = [r for r, v in fixed if r[1] is not None and r[1] > 17.0]
        if foot:
            A('- 页脚带起始 top ≈ %.2f，内容不得压入' % min(r[1] for r in foot))
        A('')

    # ---------- 4. 配色 ----------
    total = collections.Counter()
    per_page = []
    for s in p.slides:
        o = []
        walk_colors(s._element, o)
        c = collections.Counter(o)
        per_page.append(c)
        total.update(c)

    A('## 4. 配色统计（全篇 %d 个不同色值）\n' % len(total))
    A('| 色值 | 全篇次数 | 用途推断 |')
    A('|---|---|---|')
    for k, v in total.most_common(25):
        hint = dict(ROLE_HINT).get(k, '')
        A('| `#%s` | %d | %s |' % (k, v, hint))
    A('')
    A('### 逐页高频色（判断"一页用了几种颜色"）\n')
    for i, c in enumerate(per_page, 1):
        A('- **第 %d 页**：%s' % (i, ' / '.join('%s×%d' % (k, v) for k, v in c.most_common(8))))
    A('')

    # ---------- 5. 字号层级 ----------
    sizes = collections.Counter()
    for s in p.slides:
        for sh in s.shapes:
            for t, fn, c, b, sz in collect_runs(sh):
                if sz:
                    sizes[round(float(sz), 2)] += 1
    A('## 5. 字号层级分布\n')
    A('| 字号(pt) | run 数 |')
    A('|---|---|')
    for k, v in sorted(sizes.items(), reverse=True):
        A('| %s | %d |' % (k, v))
    A('')

    # ---------- 6. 表格样式 ----------
    A('## 6. 表格样式\n')
    found_tbl = False
    for i, s in enumerate(p.slides, 1):
        for sh in s.shapes:
            if not sh.has_table:
                continue
            found_tbl = True
            t = sh.table
            A('### 第 %d 页 表格 %d×%d\n' % (i, len(t.rows), len(t.columns)))
            A('| cell | fill | 字号 | 粗体 | 字色 | 文本 |')
            A('|---|---|---|---|---|---|')
            for ri, row in enumerate(t.rows):
                for ci, cell in enumerate(row.cells):
                    try:
                        fill = str(cell.fill.fore_color.rgb)
                    except Exception:
                        fill = '?'
                    fs = bd = col = None
                    for para in cell.text_frame.paragraphs:
                        for r in para.runs:
                            fs = r.font.size.pt if r.font.size else None
                            bd = r.font.bold
                            try:
                                col = str(r.font.color.rgb) if r.font.color and r.font.color.type is not None else None
                            except Exception:
                                col = None
                            break
                        if fs or bd is not None:
                            break
                    A('| r%dc%d | %s | %s | %s | %s | %s |' % (
                        ri, ci, fill, fs, bd, col,
                        cell.text.replace('\n', ' / ')[:40].replace('|', '/')))
            A('')
    if not found_tbl:
        A('_无表格_\n')

    # ---------- 7. 逐页结构 ----------
    A('## 7. 逐页结构概要\n')
    for i, s in enumerate(p.slides, 1):
        A('### 第 %d 页  ·  版式：%s\n' % (i, s.slide_layout.name))
        try:
            if s.has_notes_slide:
                nt = s.notes_slide.notes_text_frame.text.strip()
                if nt:
                    A('> **备注页**：%s\n' % nt[:600].replace('\n', ' '))
        except Exception:
            pass
        A('| # | name | left | top | w | h | 文本 |')
        A('|---|---|---|---|---|---|---|')
        for j, sh in enumerate(s.shapes, 1):
            left, top, w, h = shape_rect(sh)
            runs = collect_runs(sh, limit=None if args.full else 6)
            txt = ' / '.join(r[0] for r in runs)
            if not args.full:
                txt = txt[:300]
            else:
                txt = ' ⏎ '.join(
                    '%s[%s,%spt,%s,%s]' % (r[0][:120], r[1], r[4], r[2], 'B' if r[3] else '')
                    for r in runs)
            A('| %d | %s | %s | %s | %s | %s | %s |' % (
                j, sh.name, left, top, w, h, txt.replace('|', '/')))
            if sh.has_table:
                A('| | ↳ 表格 %d×%d | | | | | |' % (len(sh.table.rows), len(sh.table.columns)))
        A('')

    md = '\n'.join(L)
    if args.out:
        with open(args.out, 'w', encoding='utf-8') as f:
            f.write(md)
        print('已写入：%s  （%d 字符）' % (args.out, len(md)))
    else:
        print(md)


if __name__ == '__main__':
    main()
