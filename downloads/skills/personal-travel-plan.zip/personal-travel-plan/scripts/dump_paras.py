# -*- coding: utf-8 -*-
"""打印 docx 表格之外的全部段落（按文档顺序），用于核对章节结构。

用法：
  python dump_paras.py <file.docx>
输出：P001 | 段落文本 ...，表格位置标记为 [TABLE]。
"""
import sys
import re
import zipfile

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TAG = r"<w:t(?:\s[^>]*)?>(.*?)</w:t>"


def main():
    if len(sys.argv) < 2:
        print("usage: python dump_paras.py <file.docx>")
        return 1
    with zipfile.ZipFile(sys.argv[1]) as z:
        xml = z.read("word/document.xml").decode("utf-8")

    body = re.search(r"<w:body>(.*)</w:body>", xml, re.S).group(1)
    chunks = re.split(r"(<w:tbl>.*?</w:tbl>)", body, flags=re.S)
    n = 0
    try:
        for ch in chunks:
            if ch.startswith("<w:tbl>"):
                print("[TABLE]")
                continue
            for p in re.findall(r"<w:p(?:\s[^>]*)?>.*?</w:p>", ch, re.S):
                t = "".join(re.findall(TAG, p, re.S)).strip()
                if t:
                    n += 1
                    print("P%03d | %s" % (n, t))
    except (BrokenPipeError, OSError):
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
