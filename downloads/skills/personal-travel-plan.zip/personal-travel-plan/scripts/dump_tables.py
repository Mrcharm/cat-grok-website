# -*- coding: utf-8 -*-
"""按 <w:tbl> 顺序打印 docx 全部表格内容。

用法：
  python dump_tables.py <file.docx>
输出：TABLE[i] rows=N，每行单元格用 " || " 分隔（单元格内多段落用 " / " 分隔）。
"""
import sys
import re
import zipfile

# Windows 控制台/管道保护：避免中文输出或断管时抛 OSError
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

W = re.compile(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>", re.S)


def txt(s):
    return "".join(W.findall(s))


def main():
    if len(sys.argv) < 2:
        print("usage: python dump_tables.py <file.docx>")
        return 1
    with zipfile.ZipFile(sys.argv[1]) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    tbls = re.findall(r"<w:tbl>.*?</w:tbl>", xml, re.S)
    try:
        print("total tables:", len(tbls))
        for i, tb in enumerate(tbls):
            rows = re.findall(r"<w:tr(?:\s[^>]*)?>.*?</w:tr>", tb, re.S)
            print("=" * 70)
            print("TABLE[%d] rows=%d" % (i, len(rows)))
            for r, row in enumerate(rows):
                cells = re.findall(r"<w:tc>.*?</w:tc>", row, re.S)
                vals = []
                for c in cells:
                    paras = re.findall(r"<w:p(?:\s[^>]*)?>.*?</w:p>", c, re.S)
                    vals.append(" / ".join(txt(p) for p in paras))
                print("  R%02d | %s" % (r, " || ".join(vals)))
    except (BrokenPipeError, OSError):
        # 被 head / less 截断时静默退出
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
