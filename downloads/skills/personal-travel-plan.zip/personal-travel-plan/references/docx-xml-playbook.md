# DOCX 直改 XML 操作手册

> 场景：在已有攻略 docx 上做批量文字/表格修改，且不能破坏版式。
> 结论先说：**不要用 editor_sdk 按 table_id 批量写**，直接改 `word/document.xml`。

## 为什么放弃 editor_sdk

- `open_file` 重新打开会**重新分配 table_id**；每次 `doc_set_table_cells` 之后 table_id 还可能再次重排
- 结果是：调用返回 ok，但内容没落盘；或者报 `table_id not found`
- `save_file` 在预览面板持有句柄时抛 `Export file is occupied`

**可靠做法**：zipfile 读出 `word/document.xml`，正则定位表格/行/单元格，替换后重写 zip，只替换这一个 entry。

## 运行环境

```bash
python script.py
```

## 一、定位结构

```python
import re, zipfile
xml = zipfile.ZipFile(SRC).read("word/document.xml").decode("utf-8")
tbls = re.findall(r"<w:tbl>.*?</w:tbl>", xml, re.S)      # 表格按出现顺序，index 稳定
rows = re.findall(r"<w:tr(?:\s[^>]*)?>.*?</w:tr>", tb, re.S)
cells = re.findall(r"<w:tc>.*?</w:tc>", row, re.S)
```

坑 1：**表格 index 稳定，table_id 不稳定**。永远按 `<w:tbl>` 出现顺序定位。

坑 2：**行号是 1 基换算**。若按 `rows[r-1]` 取行，数据第一行是 `r=2`（`r=1` 是表头）。写脚本前先 dump 一遍确认，别凭直觉。

## 二、取文本的正则（关键）

```python
TAG     = r"<w:t(?:\s[^>]*)?>.*?</w:t>"
OPENTAG = r"<w:t(?:\s[^>]*)?>"
```

**坑 3：绝不能写 `<w:t[^>]*>`** —— 它会匹配到 `<w:tcW w:w="1728" .../>` 这类空元素，导致"多个 w:t 跳过"甚至污染 `tcPr`。必须写 `<w:t(?:\s[^>]*)?>`。

## 三、跨 run 替换（段落改写必用）

Word 会把一句话拆成多个 `<w:t>` run。做法：

1. 把所有 run 文本拼成 `concat`
2. 在 `concat` 里 `find(old)` 拿区间
3. 命中的第一个 run 写入 `pre + new + post`，其余受影响 run 只保留 `post`

```python
def replace_sub(cont, old, new):
    tags = re.findall(TAG, cont, re.S)
    texts = [re.sub(r"^" + OPENTAG + r"|</w:t>$", "", t, flags=re.S) for t in tags]
    concat = "".join(texts)
    idx = concat.find(old)
    if idx < 0:
        return None
    end = idx + len(old)
    pos, inserted, nt = 0, False, []
    for t in texts:
        rs, re_ = pos, pos + len(t)
        pos = re_
        if re_ <= idx or rs >= end:
            nt.append(t)
        else:
            pre  = t[:max(0, idx - rs)]
            post = t[max(0, min(len(t), end - rs)):]
            if not inserted:
                nt.append(pre + new + post); inserted = True
            else:
                nt.append(post)
    out = cont
    for tag, t2 in zip(tags, nt):
        m = re.match(r"(" + OPENTAG + r").*(</w:t>)", tag, re.S)
        out = out.replace(tag, m.group(1) + esc(t2) + m.group(2), 1)
    return out
```

`esc()` 只处理 `& < >` 三个字符。

## 四、整格重写（短值单元格）

保留第一个 run 的 `rPr`（字体/字号/颜色），其余 run 置空：

```python
def set_full(cont, new, expect):
    tags, texts = runs_of(cont)
    if expect not in "".join(texts):
        return None                      # expect 是防误伤的护栏
    return rebuild(cont, tags, [new] + [""] * (len(tags) - 1))
```

**每个编辑都必须带 `expect`**，否则改错格你不知道。

## 五、删除：最危险的一步

**坑 4：不要按 run 内容直接删。** 实例：为清理文末历史遗留的 `“”`，按 run 文本 `”“` 精准清除，结果打中的是正文里 `别信“央视推荐”“金奖得主”招牌` 的**正常引号边界**（前一句的闭合号 + 后一句的开启号，在中文里几乎是常态），文末那对儿反而没动。

规则：

1. 删除前先做**文本级定位**：把目标段落/单元格的 `concat` 打出来，确认前后 30 字上下文
2. 段落删除用**足够长的唯一子串**匹配（`"平面方案（强烈建议）："` 这种），不要用短词
3. 表格删除按 index，**先记下 18 张表的 index，再从后往前删**（删前面的会让后面全部错位）
4. 删完重新数 `<w:tbl>`，确认数量等于预期

## 六、写回

```python
with zipfile.ZipFile(DST, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "word/document.xml":
            data = xml.encode("utf-8")
        zout.writestr(item, data)
```

覆盖原文件前先写 `.tmp` 再 `os.replace`，避免预览持有句柄时写坏。

## 七、验证（缺一不可）

1. `dump_tables.py`：打印每张表每格 `concat`，肉眼扫一遍关键表
2. `dump_paras.py`：打印表格外全部段落，确认章节顺序与新增/删除
3. 关键词计数：预期为 0 的（旧价格、旧表述）必须为 0；预期保留的（changelog 里的历史表述）要能解释
4. `zipfile.ZipFile(DST).testzip() is None`
5. 表格数量、段落数量前后对比

**关键词计数是最有效的回归测试**：旧值残留 = 有格子没改到。

## 八、常用小工具

| 脚本 | 作用 | 位置 |
|---|---|---|
| `dump_tables.py` | 按 index 打印全部表格，`" \|\| "` 分隔单元格 | 本技能 `scripts/` 自带 |
| `dump_paras.py` | 打印表格外段落（用 `<w:tbl>` 切分 body） | 本技能 `scripts/` 自带 |
| `grep_ctx.py` | 关键词定位「第几张表第几行第几格 / 哪个段落」 | 按项目临时写 |
| `diag.py` | 打印指定表行/列数 + 每格 run 数与 concat，定位行号错位 | 按项目临时写 |

```bash
python scripts/dump_tables.py "<file.docx>"
python scripts/dump_paras.py "<file.docx>"
```

编辑脚本放 `output/<project>/tmp/`，每个版本一个 `vN_xml_edit.py`，保留历史便于回溯与回滚。
