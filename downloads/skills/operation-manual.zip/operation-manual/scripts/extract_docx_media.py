#!/usr/bin/env python3
"""Extract embedded media from a DOCX without modifying the source file."""
from pathlib import Path
import argparse, zipfile

parser = argparse.ArgumentParser()
parser.add_argument('docx', type=Path)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(args.docx) as z:
    for name in z.namelist():
        if name.startswith('word/media/') and not name.endswith('/'):
            target = args.out / Path(name).name
            target.write_bytes(z.read(name))
            print(target)
