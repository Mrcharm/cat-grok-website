#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [ROOT/'SKILL.md', ROOT/'README.md', ROOT/'manifest.json', ROOT/'manifest.txt', ROOT/'templates', ROOT/'references', ROOT/'examples']
missing = [str(p.relative_to(ROOT)) for p in required if not p.exists()]
if missing:
    print('FAIL: missing required paths:', ', '.join(missing))
    sys.exit(1)
manifest_lines = [x.strip() for x in (ROOT/'manifest.txt').read_text(encoding='utf-8').splitlines() if x.strip()]
not_found = [x for x in manifest_lines if not (ROOT/x).exists()]
if not_found:
    print('FAIL: manifest entries missing:', ', '.join(not_found))
    sys.exit(2)
print(f'PASS: {ROOT.name} structure valid; {len(manifest_lines)} files listed.')
